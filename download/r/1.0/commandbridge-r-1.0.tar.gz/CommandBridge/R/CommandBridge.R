#' Bridge/R | http://commandbridge.org

#' Bridge/R enables you to get results from other languages through the Command-line Interface.
#'
#' Since the rjson module is used internally by Bridge/R for JSON conversion,
#' you should install rjson module before installing Bridge/R module.
#' @author Jeasu Kim
loadNamespace("rjson")

#' Bridge/R enables you to get results from other languages through the Command-line Interface.
#' 
#' Since the execution result is a character string,
#' it can be solved by parsing from JSON notation string result as Value Object.
#' 
#' Although the dataset is a value object used in R, it is automatically converted into a JSON notation string
#' and converted into a string that can be used in the Command-line Interface.
#' Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
#' 
#' @param  commands  Command list.
#' @param  dataset   Data set to be converted to argument.
#' @param  arg_sep   A delimiter that separates Command and Argument.
#' @return String result executed through Command-line Interface.
call <- function(commands, dataset = NULL, arg_sep = NULL) {
	json_arg <- toJsonArg(dataset)

	if (json_arg == "\"\"")  json_arg <- NULL

	for (i in seq_along(commands)) {
		if (length(grep("\\s", commands[i])) > 0 || length(grep("\\\"", commands[i])) > 0 || length(grep("'", commands[i])) > 0) {
			commands[i] = paste("\"", gsub("\\\"", "\\\\\"", commands[i], perl=TRUE), "\"", sep = "")
		}
	}

	if (!is.null(dataset)) {
		if (!is.null(arg_sep))  commands <- c(commands, c = arg_sep)

		commands <- c(commands, c = json_arg)
	}

	command <- paste(commands, collapse = " ")

	results <- system(command, intern = TRUE, ignore.stderr = FALSE)
	paste(results, collapse = "\n")
}

#' The dataset is a value object used in R, but it is automatically converted to a JSON notation string and returns a string that can be used in Command-line Interface.
#' 
#' @param  dataset   Data set to be converted to argument.
#' @return A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
toJsonArg <- function(dataset) {
	json_arg <- ""

	if (typeof(dataset) == "character")  json_arg <- dataset
	else                                 json_arg <- rjson::toJSON(dataset)

	json_arg <- gsub("\\\\\\\\([^n|r|t|'|\"|\\\\])?", "\\\\u005c\\1", json_arg, perl=TRUE)  # replace \ [w/o escape prefix] ==> \u005c
	json_arg <- gsub("\\\\\"", "\\\\\\\\\"", json_arg, perl=TRUE)  # replace \" ==> \\"
	json_arg <- gsub("\\\"", "\\\\\"", json_arg, perl=TRUE)    # replace " ==> \"
	json_arg <- gsub("&", "\\\\u0026", json_arg, perl=TRUE)    # for unix shell & dos command
	json_arg <- gsub("!", "\\\\u0021", json_arg, perl=TRUE)    # for unix shell
	json_arg <- gsub("`", "\\\\u0060", json_arg, perl=TRUE)    # for unix shell
	json_arg <- gsub("[$]", "\\\\u0024", json_arg, perl=TRUE)  # for unix shell
	json_arg <- gsub("<", "\\\\u003c", json_arg, perl=TRUE)    # for dos command
	json_arg <- gsub(">", "\\\\u003e", json_arg, perl=TRUE)    # for dos command
	json_arg <- gsub("[|]", "\\\\u007c", json_arg, perl=TRUE)  # for dos command

	paste("\"", json_arg, "\"", sep = "")
}