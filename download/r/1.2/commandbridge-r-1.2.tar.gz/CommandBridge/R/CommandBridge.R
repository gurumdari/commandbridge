#' Bridge/R | http://commandbridge.org

#' Bridge/R enables you to get results from other languages through the Command-line Interface.
#'
#' Since the rjson module is used internally by Bridge/R for JSON conversion,
#' you should install rjson module before installing Bridge/R module.
#' 
#' @version 1.0, 2017-02-02  first release for R
#' @version 1.2, 2018-12-14  Option support for ignoring the stderr. / Escaping strings of the commands array.
#' @author  Jeasu Kim
loadNamespace("rjson")

cacheEnv <- new.env()
assign("bridge_ignore_stderr", FALSE, envir=cacheEnv)

#' Bridge/R enables you to get results from other languages through the Command-line Interface.
#' 
#' Since the execution result is a character string,
#' it can be solved by parsing from JSON notation string result as Value Object.
#' 
#' Although the dataset is a value object used in R, it is automatically converted into a JSON notation string
#' and converted into a string that can be used in the Command-line Interface.
#' Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
#' 
#' @param  commands  Command list.
#' @param  dataset   Data set to be converted to argument.
#' @param  arg_sep   A delimiter that separates Command and Argument.
#' @return String result executed through Command-line Interface.
call <- function(commands, dataset = NULL, arg_sep = NULL) {
	json_arg <- toCommandArg(dataset)

	if (json_arg == "\"\"")  json_arg <- NULL

	for (i in seq_along(commands)) {
		commands[i] <- toCommandArg(commands[i])
	}

	if (!is.null(dataset)) {
		if (!is.null(arg_sep))  commands <- c(commands, c = arg_sep)

		commands <- c(commands, c = json_arg)
	}

	# command <- paste(commands, collapse = " ")
	command <- paste(paste(commands, collapse = " "), "2>&1", collapse = " ")
	results <- system(command, intern = TRUE, ignore.stderr = get("bridge_ignore_stderr", envir=cacheEnv))

	paste(results, collapse = "\n")
}

#' This function ignores the stderr.
#'
#' @param ignore  Whether to ignore the stderr.
#' @since 1.2
ignoreStderr <- function(ignore) {
	assign("bridge_ignore_stderr", ignore, envir=cacheEnv)
}

#' The function escapes the dataset to be available as an argument to the Command-line Interface.
#'  
#' The dataset is a string value, Vector or List used in R.
#' If dataset is a Vector or List, it is automatically converted to a JSON notation string.
#'
#' The function escapes with a code notation of the unicode that is only available in the JSON notation string.
#' However, since toCommandArg function escapes with the command-line interface escape of the specific OS,
#' toCommandArg can be applied to other string arguments as well as the JSON notation string.
#' 
#' @param  dataset  Data set to be converted to argument.
#' @return A string that is escaped to be available as an argument to the Command-line Interface.
#' @deprecated As of version 1.2, use toCommandArg instead.
toJsonArg <- function(dataset) {
	json_arg <- ""

	if (typeof(dataset) == "character")  json_arg <- dataset
	else                                 json_arg <- rjson::toJSON(dataset)

	json_arg <- gsub("\\\\\\\\([^n|r|t|'|\"|\\\\])?", "\\\\u005c\\1", json_arg, perl=TRUE)  # replace \ [w/o escape prefix] ==> \u005c
	json_arg <- gsub("\\\\\"", "\\\\\\\\\"", json_arg, perl=TRUE)  # replace \" ==> \\"
	json_arg <- gsub("\\\"", "\\\\\"", json_arg, perl=TRUE)    # replace " ==> \"
	json_arg <- gsub("&", "\\\\u0026", json_arg, perl=TRUE)    # for unix shell & dos command
	json_arg <- gsub("!", "\\\\u0021", json_arg, perl=TRUE)    # for unix shell
	json_arg <- gsub("`", "\\\\u0060", json_arg, perl=TRUE)    # for unix shell
	json_arg <- gsub("[$]", "\\\\u0024", json_arg, perl=TRUE)  # for unix shell
	json_arg <- gsub("<", "\\\\u003c", json_arg, perl=TRUE)    # for dos command
	json_arg <- gsub(">", "\\\\u003e", json_arg, perl=TRUE)    # for dos command
	json_arg <- gsub("[|]", "\\\\u007c", json_arg, perl=TRUE)  # for dos command

	paste("\"", json_arg, "\"", sep = "")
}

#' The function escapes the dataset to be available as an argument to the Command-line Interface.
#'  
#' The dataset is a string value, Vector or List used in R.
#' If dataset is a Vector or List, it is automatically converted to a JSON notation string.
#' 
#' @param  dataset  Data set to be converted to argument.
#' @return A string that is escaped to be available as an argument to the Command-line Interface.
#' @since  1.2
toCommandArg <- function(dataset) {
	args <- ""

	if (typeof(dataset) == "character")  args <- dataset
	else                                 args <- rjson::toJSON(dataset)

	if (Sys.info()['sysname'] == "Windows") {
		#shQuote(args, type="cmd")
		args <- gsub("\\\"", "\\\\\"", args, perl=TRUE);
		args <- gsub("((\\\\)+)\\\\\\\"", "\\1\\1\\\\\"", args, perl=TRUE);
		args <- paste('"', args, '"', sep = "")
	} else {
		shQuote(args, type="sh")
	}
}