/*! Bridge/Node.js | http://commandbridge.org */

/**
 * Bridge/Node.js enables you to get results from other languages through the Command-line Interface.
 * 
 * @version 1.0, 2017-02-02  first release for Node.js
 * @version 1.2, 2018-12-14  Option support for ignoring the contents started with warning. / Escaping strings of the commands array.
 * @author Jeasu Kim
 */
module.exports = {

	/**
	 * Bridge/Node.js enables you to get results from other languages through the Command-line Interface.
	 * 
	 * The execution result is passed to the last parameter as callback Function.
	 * The normal result is passed to the first parameter as a string,
	 * and the error is passed to the second parameter as a string.
	 * In order to pass it as a value object, it is possible to pass the result to the JSON notation string in the callee language.
	 * 
	 * Although the dataset is a value object used in JavaScript,
	 * it is automatically converted into a JSON notation string by JSON.stringify function
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
	 * 
	 * @param  {Array} commands     Command list.
	 * @param  {Object} dataset     {@omittable} Data set to be converted to argument.
	 * @param  {String} arg_sep     {@omittable} A delimiter that separates Command and Argument.
	 * @param  {Function} callback  {@nullable} A callback function that takes a normal result string and an error string as parameters.
	 */
	call: function(commands, dataset, argSep, callback) {
		if (typeof dataset == "function") {
			callback = dataset;
			dataset  = null;
			argSep   = null;
		}

		if (typeof argSep == "function") {
			callback = argSep;
			argSep = null;
		}

		for (var i = 0; i < commands.length; i++) {
			commands[i] = this.toCommandArg(commands[i]);
		}

		var jsonArg = this.toCommandArg(dataset);
		if (jsonArg == "\"\"")  jsonArg = null;

		if (jsonArg) {
			if (argSep)  commands.push(argSep);

			commands.push(jsonArg);
		}

		var command = commands.join(" ");

		require('child_process').exec(command, (err, stdout, stderr) => {
			if (stderr && this.ignore_conf && this.ignore_conf.prefix) {
				var re = new RegExp("^(" + this.ignore_conf.prefix + "(.*\\r?\\n){" + this.ignore_conf.line + "})*", "i");
				var replaced_stderr = stderr.replace(re, "");

				if (replaced_stderr.trim() == "")  stderr = "";
			}

			if (callback)  callback(stdout.replace(/\s+$/, ""), stderr.replace(/\s+$/, ""));
		});
	},

	/**
	 * This function ignores the contents started with warning.
	 * 
	 * It can not be caught because it finds and deletes only the lines starting waring from the stderr.
	 * 
	 * @param  {Number} line    The number of lines of warning messages to ignore.
	 * @param  {String} prefix  {@nullable<"warning">} Warning message prefix ignoring case.
	 * @since  1.2
	 */
	ignoreWarning: function(line, prefix) {
		if (prefix == null)  prefix = "warning";

		line = parseInt(line);

		if (isNaN(line)) {
			throw new Error("line parameter of ignoreWarning function should be int.");
		} else {
			if (line > 0) {
				this.ignore_conf = {
					prefix: prefix,
					line:   line
				};
			}
		}
	},

	/**
	 * This function escapes the dataset to be available as an argument to the Command-line Interface.
	 *  
	 * The dataset is a string value or JSON Object used in JavaScript.
	 * If dataset is a JSON Object, it is automatically converted to a JSON notation string.
	 * 
	 * This function escapes with a code notation of the unicode that is only available in the JSON notation string.
	 * However, since toCommandArg function escapes with the command-line interface escape of the specific OS,
	 * toCommandArg can be applied to other string arguments as well as the JSON notation string.
	 * 
	 * @param  {String | Object} dataset  Data set to be converted to argument.
	 * @return {String} A string that is escaped to be available as an argument to the Command-line Interface.
	 * @deprecated As of version 1.2, use toCommandArg instead.
	 */
	toJsonArg: function(dataset) {
		if (dataset == null)  return null;

		var jsonArg = null;

		if (typeof dataset == "string")  jsonArg = dataset;
		else                             jsonArg = JSON.stringify(dataset);

		jsonArg = jsonArg.replace(/\\\\([^n|r|t|'|\"|\\])?/g, "\\u005c$1");  // replace \\ [w/o escape prefix] ==> \u005c
		jsonArg = jsonArg.replace(/\\\"/g, "\\\\\"");  // replace \" ==> \\"
		jsonArg = jsonArg.replace(/\"/g, "\\\"");      // replace " ==> \"
		jsonArg = jsonArg.replace(/&/g, "\\u0026");    // for unix shell & dos command
		jsonArg = jsonArg.replace(/!/g, "\\u0021");    // for unix shell
		jsonArg = jsonArg.replace(/`/g, "\\u0060");    // for unix shell
		jsonArg = jsonArg.replace(/[$]/g, "\\u0024");  // for unix shell
		jsonArg = jsonArg.replace(/</g, "\\u003c");    // for dos command
		jsonArg = jsonArg.replace(/>/g, "\\u003e");    // for dos command
		jsonArg = jsonArg.replace(/[|]/g, "\\u007c");  // for dos command

		return "\"" + jsonArg + "\"";
	},

	/**
	 * This function escapes the dataset to be available as an argument to the Command-line Interface.
	 *  
	 * The dataset is a string value or JSON Object used in JavaScript.
	 * If dataset is a JSON Object, it is automatically converted to a JSON notation string.
	 * 
	 * @param  {String | Object} dataset  Data set to be converted to argument.
	 * @return {String} A string that is escaped to be available as an argument to the Command-line Interface.
	 * @since  1.2
	 */
	toCommandArg: function(dataset) {
		if (dataset == null)  return null;

		var args = null;

		if (typeof dataset == "string")  args = dataset;
		else                             args = JSON.stringify(dataset);

		if (process.platform.toUpperCase().startsWith("WIN")) {
			args = args.replace(/\"/g, "\\\"");
			return '"' + args.replace(/((\\)+)\\\"/g, "$1$1\\\"") + '"';
		} else {
			args = "'" + args.replace(/'/g , "'\\''") + "'";
			args = args.replace(/\\'''\\'/g, "\\'\\'");
			args = args.replace(/^''\\''/g , "\\''");
			return args.replace(/'\\'''$/g , "'\\'");
		}
	}
};