<?php
/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * http://commandbridge.org
 */
namespace Gurumdari;

/**
 * Bridge/PHP enables you to get results from other languages through the Command-line Interface.
 * 
 * Bridge/PHP is supported since PHP 5.3.
 * 
 * @version 1.0, 2017-02-02  first release for PHP
 * @version 1.2, 2018-12-14  Option support for ignoring the contents started with warning. / Escaping strings of the $commands array.
 * @author  Jeasu Kim
 */
class CommandBridge {
	private static $ignore_conf = [];

	/**
	 * Bridge/PHP enables you to get results from other languages through the Command-line Interface.
	 * 
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * Although the $dataset is a value object used in PHP, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
	 * 
	 * @param  $commands  Command list.
	 * @param  $dataset   Data set to be converted to argument.
	 * @param  $arg_sep   A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 */
	public function call($commands, $dataset = null, $arg_sep = null) {
		$json_arg = $this->toCommandArg($dataset);
		if ($json_arg == "\"\"")  $json_arg = null;

		for ($i = 0; $i < count($commands); $i++) {
			$commands[$i] = $this->toCommandArg($commands[$i]);
		}

		if (isset($json_arg)) {
			if (isset($arg_sep))  array_push($commands, $arg_sep);
			array_push($commands, $json_arg);
		}

		array_push($commands, "2>&1");

		$pipe = @\popen(implode(" ", $commands), "r");
		$result = stream_get_contents($pipe);

		$error_code = pclose($pipe);

		if ($error_code === 0) {
			if (isset($this::$ignore_conf['prefix'])) {
				$result = preg_replace("/^({$this::$ignore_conf['prefix']}(.*\r?\n){".$this::$ignore_conf['line']."})*/i", "", "$result\n");
			}
		} else {
			throw new \Exception(rtrim($result));
		}

		return rtrim($result);
	}

	/**
	 * This function ignores the contents started with warning.
	 * 
	 * It can not be caught because it finds and deletes only the lines starting waring prefix from the result of call function.
	 * 
	 * @param $line    The number of lines of warning messages to ignore.
	 * @param $prefix  Warning message prefix ignoring case.
	 * @since 1.2
	 */
	public function ignoreWarningStart($line, $prefix = 'warning') {
		if (is_int($line)) {
			if ($line > 0) {
				$this::$ignore_conf = [
					'prefix' => $prefix,
					'line'   => $line
				];
			}
		} else {
			throw new \Exception('$line parameter of ignoreWarningStart function should be integer.');
		}
	}

	/**
	 * This function escapes the $dataset to be available as an argument to the Command-line Interface.
	 *  
	 * The $dataset is a string value or associative array used in PHP.
	 * If $dataset is a associative array, it is automatically converted to a JSON notation string.
	 * 
	 * This function escapes with a code notation of the unicode that is only available in the JSON notation string.
	 * However, since toCommandArg function escapes with the command-line interface escape of the specific OS,
	 * toCommandArg can be applied to other string arguments as well as the JSON notation string.
	 * 
	 * @param  $dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available as an argument to the Command-line Interface.
	 * @deprecated As of version 1.2, use toCommandArg instead.
	 */
	public function toJsonArg($dataset) {
		if (is_null($dataset))  return null;

		$json_arg = null;
		if (gettype($dataset) == "string")  $json_arg = $dataset;
		else                                $json_arg = json_encode($dataset);

		$json_arg = preg_replace("/\\\\\\\\([^n|r|t|'|\"|\\\\])?/m", "\u005c$1", $json_arg);  # replace \ [w/o escape prefix] ==> \u005c
		$json_arg = preg_replace("/\\\\\\\"/m", "\\\\\\\"", $json_arg);  # replace \" ==> \\"
		$json_arg = preg_replace("/\\\"/m", "\\\"", $json_arg);          # replace " ==> \"
		$json_arg = preg_replace("/&/m", "\u0026", $json_arg);    # for unix shell & dos command
		$json_arg = preg_replace("/!/m", "\u0021", $json_arg);    # for unix shell
		$json_arg = preg_replace("/`/m", "\u0060", $json_arg);    # for unix shell
		$json_arg = preg_replace("/[$]/m", "\u0024", $json_arg);  # for unix shell
		$json_arg = preg_replace("/</m", "\u003c", $json_arg);    # for dos command
		$json_arg = preg_replace("/>/m", "\u003e", $json_arg);    # for dos command
		$json_arg = preg_replace("/\|/m", "\u007c", $json_arg);   # for dos command
		return "\"$json_arg\"";
	}

	/**
	 * This function escapes the $dataset to be available as an argument to the Command-line Interface.
	 *  
	 * The $dataset is a string value or associative array used in PHP.
	 * If $dataset is a associative array, it is automatically converted to a JSON notation string.
	 * 
	 * @param  $dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available as an argument to the Command-line Interface.
	 * @since  1.2
	 */
	public function toCommandArg($dataset) {
		if (is_null($dataset))  return null;

		$cmd_arg = null;
		if (gettype($dataset) == 'string')  $cmd_arg = $dataset;
		else                                $cmd_arg = json_encode($dataset);

		if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
			$cmd_arg = preg_replace("/\\\"/", "\\\"", $cmd_arg);
			$cmd_arg = preg_replace("/((\\\\)+)\\\\\\\"/", "$1$1\\\"", $cmd_arg);
			$cmd_arg = "\"$cmd_arg\"";
		} else {
			$cmd_arg = escapeshellarg($cmd_arg);
		}

		return $cmd_arg;
	}
}