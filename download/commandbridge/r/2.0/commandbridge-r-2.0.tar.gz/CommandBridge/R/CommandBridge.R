#' CommandBridge/R | https://commandbridge.org

#' Bridge/R enables you to get results from other languages through the Command-line Interface.
#'
#' Since the rjson module is used internally by Bridge/R for JSON conversion,
#' you should install rjson module before installing Bridge/R module.
#' 
#' @version 1.0, 2017-02-02  first release for R
#' @version 1.2, 2018-12-14  Option support for ignoring the stderr. / Escaping strings of the commands array.
#' @version 1.3, 2019-03-13  Supports to receive the result of calling remote server's command with CommandBridge via REST API.
#' @version 2.0, 2020-04-14  Remove deprecated APIs.
#' @author  Jeasu Kim
loadNamespace("rjson")

cacheEnv <- new.env()
assign("__bridge_options__", list(), envir=cacheEnv)

#' Bridge/R enables you to get results from other languages through the Command-line Interface.
#' 
#' Since the execution result is a character string,
#' it can be solved by parsing from JSON notation string result as Value Object.
#' 
#' Although the dataset is a value object used in R, it is automatically converted into a JSON notation string
#' and converted into a string that can be used in the Command-line Interface.
#' Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
#' 
#' @param  commands  Command list.
#' @param  dataset   Data set to be converted to argument.
#' @param  arg_sep   A delimiter that separates Command and Argument.
#' @return String result executed through Command-line Interface.
call <- function(commands, dataset = NULL, arg_sep = NULL) {
	options <- get("__bridge_options__", envir=cacheEnv)

	if (typeof(options$remote) == "list") {
		library("httr", quietly=TRUE)

		remote_options <- options$remote

		protocol <- 'http'
		host     <- 'localhost'
		port     <- 80
		route    <- '/remotebridge'

		if (!is.null(remote_options$protocol))  protocol <- remote_options$protocol
		if (!is.null(remote_options$host    ))  host     <- remote_options$host
		if (!is.null(remote_options$port    ))  port     <- remote_options$port
		if (!is.null(remote_options$route   ))  route    <- remote_options$route

		options4remote <- options;
		options4remote$remote <- NULL

		json_data <- dataset;
		if (typeof(dataset) == "list") {
			json_data <- rjson::toJSON(dataset);
		}

		params <- list(
			'commands[]' = commands,
			'dataset'    = json_data,
			'arg_sep'    = arg_sep,
			'options'    = rjson::toJSON(options4remote),
			'username'   = remote_options$username,
			'password'   = remote_options$password
		)

		url <- sprintf("%s://%s:%d%s", protocol, host, port, route)
		response <- POST(url, content_type("application/x-www-form-urlencoded"), body = toFormURL(params), encode = "raw")
		result <- content(response, "text")

		if (startsWith(gsub("[[:blank:]]", "", result), '{"error-')) {
			error <- rjson::fromJSON(result)

			if (typeof(error[["error-code"]]) == "double" && typeof(error[["error-message"]]) == "character") {
				stop(error[["error-message"]])
			}
		}

		result
	} else {
		json_arg <- toCommandArg(dataset)

		if (json_arg == "\"\"")  json_arg <- NULL

		for (i in seq_along(commands)) {
			commands[i] <- toCommandArg(commands[i])
		}

		if (!is.null(dataset)) {
			if (!is.null(arg_sep))  commands <- c(commands, c = arg_sep)

			commands <- c(commands, c = json_arg)
		}

		ignore_stderr <- FALSE

		if (typeof(options$ignore) == "list" && typeof(options$ignore$type) == "character") {
			if (options$ignore$type == "error")  ignore_stderr <- TRUE
		}

		command <- paste(paste(commands, collapse = " "), "2>&1", collapse = " ")
		results <- system(command, intern = TRUE, ignore.stderr = ignore_stderr)
		result <- paste(results, collapse = "\n")


		if (typeof(options$ignore) == "list" && typeof(options$ignore$type) == "character" && options$ignore$type == "warning") {
			ignore_prefix <- "warning"
			ignore_line   <- 1

			if (typeof(options$ignore$warning) == "list") {
				ignore_warning <- options$ignore$warning

				if (typeof(ignore_warning$prefix) == "character" && ignore_warning$prefix != "") {
					ignore_prefix <- ignore_warning$prefix;
				}

				if (typeof(ignore_warning$line) == "double") {
					ignore_line <- ignore_warning$line;
				}
			}

			result <- gsub(paste("^(", ignore_prefix, "(.*\r?\n){", ignore_line, "})*", sep = ""), "", result, ignore.case = TRUE, perl=TRUE)
		}

		result
	}
}

#' This function sets the configuration.
#' 
#' options is a list type or JSON notation character of the following structure.
#' 
#' list(
#'   remote = list(
#'     protocol = "{character} @nullable<'http'>",
#'     host     = "{character} @nullable<'localhost'>",
#'     port     = "{double} @nullable<80>",
#'     route    = "{character} @nullable<'/remotebridge'>",
#'     username = "{character}",
#'     password = "{character}"
#'   ),
#'   ignore = list(
#'     type = "{character} ['error' or 'warning']",
#'     warning = list(
#'       line   = "{double} @nullable<1>",
#'       prefix = "{character} @nullable<'warning'>"
#'     )
#'   )
#' )
#' 
#' If you can not execute the command in Local, when you run RemoteBridge add-on module from Remote Server,
#' you can receive the result of calling Remote Server's command with CommandBridge via REST API.
#' At this time, the setting for communication with RemoteBridge can be set to options$remote.
#' 
#' If a warning or error occurs when calling a command with CommandBridge/R,
#' an exception is generated instead of the result or a warning is output to the result value.
#' You can ignore the warning or error through options$ignore setting.
#' If options$ignore$type is 'warning',
#' You can additionally set the options$ignore$warning to include a prefix to be recognized as a warning
#' and the number of lines to ignore when starting with the letter corresponding to the prefix.
#' 
#' CommandBridge/R returns the result of combining stderr and stdout.
#' If options$ignore$type is set to 'error', ignore stderr and return only stdout.
#' If options$ignore$type is set to 'warning',
#' only the lines corresponding to the warning set in the prefix are removed from the result of combining stderr and stdout.
#' 
#' @param options  The configuration options.
#' @since 1.3
setConfig <- function(options) {
	if (is.null(options)) {
		assign("__bridge_options__", list(), envir=cacheEnv)
	} else if (typeof(options) == "list") {
		assign("__bridge_options__", options, envir=cacheEnv)
	} else if (typeof(options) == "character") {
		assign("__bridge_options__", rjson::fromJSON(options), envir=cacheEnv)
	} else {
		stop("options should be list or character.")
	}
}

#' The function escapes the dataset to be available as an argument to the Command-line Interface.
#'  
#' The dataset is a string value, Vector or List used in R.
#' If dataset is a Vector or List, it is automatically converted to a JSON notation string.
#' 
#' @param  dataset  Data set to be converted to argument.
#' @return A string that is escaped to be available as an argument to the Command-line Interface.
#' @since  1.2
toCommandArg <- function(dataset) {
	args <- ""

	if (typeof(dataset) == "character") {
		if (length(dataset) > 1)  args <- rjson::toJSON(dataset)
		else                      args <- dataset
	} else {
		args <- rjson::toJSON(dataset)
	}

	if (Sys.info()['sysname'] == "Windows") {
		#shQuote(args, type="cmd")
		args <- gsub("\\\"", "\\\\\"", args, perl=TRUE);
		args <- gsub("((\\\\)+)\\\\\\\"", "\\1\\1\\\\\"", args, perl=TRUE);
		args <- paste('"', args, '"', sep = "")
	} else {
		shQuote(args, type="sh")
	}
}

#' This function converts List into string of Form URL format.
#'
#' @param  {Object} params   List.
#' @return {String} Form URL format string.
#' @since  1.3
toFormURL <- function(params) {
	formurls <- c()

	for (name in names(params)) {
		values <- params[[name]]

		if (!is.null(values)) {
			if (typeof(values) == "character") {
				if (length(values) > 1) {
					for (value in values) {
						if (!is.null(value))  formurls <- c(formurls, paste(URLencode(name), URLencode(value), sep = '='))
					}
				} else {
					formurls <- c(formurls, paste(URLencode(name), URLencode(values), sep = '='))
				}
			} else {
				formurls <- c(formurls, paste(URLencode(name), URLencode(rjson::toJSON(values)), sep = '='))
			}
		}
	}

	formurl <- paste(formurls, collapse = '&')

	if (formurl == "") {
		NULL
	} else {
		formurl
	}
}