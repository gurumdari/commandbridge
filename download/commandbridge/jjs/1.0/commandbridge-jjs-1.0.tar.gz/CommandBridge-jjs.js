/*! Bridge/jjs | http://commandbridge.org */
var gurumdari = gurumdari || {};

/**
 * Bridge/jjs enables you to get results from other languages through the Command-line Interface.
 * 
 * Since Java 8 and later, the Nashorn JavaScript Engine allows JavaScript to be executed with the jjs command in the Command-line Interface.
 * Because the Bridge/jjs must receive the execution results of the other language via the Command-line Interface,
 * it must execute the jjs command with -scripting option.
 * You need to add the -scripting option to enable Shell scripting extensions.
 * 
 * @author Jeasu Kim
 */
gurumdari.CommandBridge = {

	/**
	 * Bridge/jjs enables you to get results from other languages through the Command-line Interface.
	 * 
	 * The execution result is passed to the last parameter as callback Function.
	 * The normal result is passed to the first parameter as a string,
	 * and the error is passed to the second parameter as a string.
	 * In order to pass it as a value object, it is possible to pass the result to the JSON notation string in the callee language.
	 * 
	 * Although the dataset is a value object used in JavaScript,
	 * it is automatically converted into a JSON notation string by JSON.stringify function
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
	 * 
	 * @param  {Array} commands     Command list.
	 * @param  {Object} dataset     {@omittable} Data set to be converted to argument.
	 * @param  {String} arg_sep     {@omittable} A delimiter that separates Command and Argument.
	 * @param  {Function} callback  {@nullable} A callback function that takes a normal result string and an error string as parameters.
	 */
	call: function(commands, dataset, argSep, callback) {
		if (typeof dataset == "function") {
			callback = dataset;
			dataset  = null;
			argSep   = null;
		}

		if (typeof argSep == "function") {
			callback = argSep;
			argSep = null;
		}

		for (var i = 0; i < commands.length; i++) {
			if (commands[i].search(/\s/) > -1 || commands[i].search(/\"/) > 0 || commands[i].search(/\'/) > 0) {
				commands[i] = "\"" + commands[i].replace(/\"/g, "\\\"") + "\"";
			}
		}

		var jsonArg = this.toJsonArg(dataset);
		if (jsonArg == "\"\"")  jsonArg = null;

		if (jsonArg) {
			if (argSep)  commands.push(argSep);

			commands.push(jsonArg);
		}

		var command = commands.join(" ");

		$EXEC(command);

		if (callback) {
			callback($OUT, $ERR);
		}
	},

	/**
	 * The dataset is a value object used in JavaScript, but it is automatically converted to a JSON notation string and returns a string that can be used in Command-line Interface.
	 * 
	 * @param  {Object} dataset  Data set to be converted to argument.
	 * @return {String} A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	 */
	toJsonArg: function(dataset) {
		if (dataset == null)  return null;

		var jsonArg = null;

		if (typeof dataset == "string")  jsonArg = dataset;
		else                             jsonArg = JSON.stringify(dataset);

		jsonArg = jsonArg.replace(/\\\\([^n|r|t|'|\"|\\])?/gm, "\\u005c$1")  // replace \\ [w/o escape prefix] ==> \u005c
		jsonArg = jsonArg.replace(/\\\"/gm, "\\\\\"")  // replace \" ==> \\"
		jsonArg = jsonArg.replace(/\"/gm, "\\\"")      // replace " ==> \"
		jsonArg = jsonArg.replace(/&/gm, "\\u0026")    // for unix shell & dos command
		jsonArg = jsonArg.replace(/!/gm, "\\u0021")    // for unix shell
		jsonArg = jsonArg.replace(/`/gm, "\\u0060")    // for unix shell
		jsonArg = jsonArg.replace(/[$]/gm, "\\u0024")  // for unix shell
		jsonArg = jsonArg.replace(/</gm, "\\u003c")    // for dos command
		jsonArg = jsonArg.replace(/>/gm, "\\u003e")    // for dos command
		jsonArg = jsonArg.replace(/[|]/gm, "\\u007c")  // for dos command

		return "\"" + jsonArg + "\"";
	}
};