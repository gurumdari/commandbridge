<?php
/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * https://commandbridge.org
 */
namespace Gurumdari;

/**
 * Bridge/PHP enables you to get results from other languages through the Command-line Interface.
 * 
 * Bridge/PHP is supported since PHP 5.3.
 * 
 * @version 1.0, 2017-02-02  first release for PHP
 * @version 1.2, 2018-12-14  Option support for ignoring the contents started with warning. / Escaping strings of the $commands array.
 * @version 1.3, 2019-03-13  Supports to receive the result of calling remote server's command with CommandBridge via REST API.
 * @version 2.0, 2020-04-14  Remove deprecated APIs.
 * @author  Jeasu Kim
 */
class CommandBridge {
	private static $options = [];

	/**
	 * Bridge/PHP enables you to get results from other languages through the Command-line Interface.
	 * 
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * Although the $dataset is a value object used in PHP, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
	 * 
	 * @param  $commands  Command list.
	 * @param  $dataset   Data set to be converted to argument.
	 * @param  $arg_sep   A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 */
	public function call($commands, $dataset = null, $arg_sep = null) {
		if (isset($this::$options['remote'])) {
			$remote_options = $this::$options['remote'];

			$protocol = 'http';
			$host     = 'localhost';
			$port     = 80;
			$route    = '/remotebridge';

			if (isset($remote_options['protocol']))  $protocol = $remote_options['protocol'];
			if (isset($remote_options['host']    ))  $host     = $remote_options['host'];
			if (isset($remote_options['port']    ))  $port     = $remote_options['port'];
			if (isset($remote_options['route']   ))  $route    = $remote_options['route'];

			$options4remote = $this::$options;
			unset($options4remote['remote']);

			$json_data = $dataset;
			if (isset($dataset) && gettype($dataset) == "array") {
				$json_data = json_encode($dataset);
			}

			$params = [
				'commands' => $commands,
				'dataset'  => $json_data,
				'arg_sep'  => $arg_sep,
				'options'  => json_encode($options4remote),
				'username' => $remote_options['username'],
				'password' => $remote_options['password']
			];

			$post_data = substr(preg_replace('/&commands%5B[0-9]+%5D=/simU', '&commands%5B%5D=', '&'.http_build_query($params)), 1);

			$result = file_get_contents("$protocol://$host:$port$route", false, stream_context_create([
				'http' => [
					'header'  => 'Content-type: application/x-www-form-urlencoded',
					'method'  => 'POST',
					'content' => $post_data
				]
			]));

			if (substr(preg_replace('/\s/', '', $result), 0, 8) === '{"error-') {
				$error = json_decode($result, true);

				if (isset($error['error-code']) && isset($error['error-message'])) {
					$error_code    = $error['error-code'];
					$error_message = $error['error-message'];

					if (is_int($error_code) && is_string($error_message)) {
						throw new \Exception($error_message);
					}
				}
			}

			return $result;
		} else {
			$json_arg = $this->toCommandArg($dataset);

			if ($json_arg == '""')  $json_arg = null;

			for ($i = 0; $i < count($commands); $i++) {
				$commands[$i] = $this->toCommandArg($commands[$i]);
			}

			if (isset($json_arg)) {
				if (isset($arg_sep))  array_push($commands, $arg_sep);
				array_push($commands, $json_arg);
			}

			if (isset($this::$options['ignore']) && isset($this::$options['ignore']['type']) && $this::$options['ignore']['type'] == 'error') {
				array_push($commands, '2>/dev/null');
				# array_push($commands, '> NUL');
			} else {
				array_push($commands, '2>&1');
			}

			exec(implode(' ', $commands), $results, $return_var);

			$result = implode("\n", $results);

			if ($return_var === 0) {
				if (isset($this::$options['ignore']) && isset($this::$options['ignore']['type']) && $this::$options['ignore']['type'] == 'warning') {
					$ignore_prefix = 'warning';
					$ignore_line   = 1;

					if (isset($this::$options['ignore']['warning'])) {
						$ignore_warning = $this::$options['ignore']['warning'];

						if (isset($ignore_warning['prefix']) && $ignore_warning['prefix'] != '') {
							$ignore_prefix = $ignore_warning['prefix'];
						}

						if (isset($ignore_warning['line']) && is_int($ignore_warning['line'])) {
							$ignore_line = $ignore_warning['line'];
						}
					}

					$result = preg_replace("/^($ignore_prefix(.*\r?\n){".$ignore_line."})*/i", "", "$result\n");
				}
			} else {
				throw new \Exception(rtrim($result));
			}

			return rtrim($result);
		}
	}

	/**
	 * This function sets the configuration.
	 * 
	 * $options is a array type or JSON notation string of the following structure.
	 * 
	 * [
	 *   'remote' => [
	 *     'protocol' => "{string} @nullable<'http'>",
	 *     'host'     => "{string} @nullable<'localhost'>",
	 *     'port'     => "{int} @nullable<80>",
	 *     'route'    => "{string} @nullable<'/remotebridge'>",
	 *     'username' => "{string}",
	 *     'password' => "{string}"
	 *   ],
	 *   'ignore' => [
	 *     'type' => "{string} ['error' or 'warning']",
	 *     'warning' => [
	 *       'line'   => "{int} @nullable<1>",
	 *       'prefix' => "{string} @nullable<'warning'>"
	 *     ]
	 *   ]
	 * ]
	 * 
	 * If you can not execute the command in Local, when you run RemoteBridge add-on module from Remote Server,
	 * you can receive the result of calling Remote Server's command with CommandBridge via REST API.
	 * At this time, the setting for communication with RemoteBridge can be set to $options['remote'].
	 * 
	 * If a warning or error occurs when calling a command with CommandBridge/PHP,
	 * an exception is generated instead of the result or a warning is output to the result value.
	 * You can ignore the warning or error through $options['ignore'] setting.
	 * If $options['ignore']['type'] is 'warning',
	 * You can additionally set the $options['ignore']['warning'] to include a prefix to be recognized as a warning
	 * and the number of lines to ignore when starting with the letter corresponding to the prefix.
	 * 
	 * CommandBridge/PHP returns the result of combining stderr and stdout.
	 * If $options['ignore']['type'] is set to 'error', ignore stderr and return only stdout.
	 * If $options['ignore']['type'] is set to 'warning',
	 * only the lines corresponding to the warning set in the prefix are removed from the result of combining stderr and stdout.
	 * 
	 * @param $options  The configuration options.
	 * @since 1.3
	 */
	public function setConfig($options) {
		if (is_null($options)) {
			$this::$options = [];
		} else if (gettype($options) == "array") {
			$this::$options = $options;
		} else if (gettype($options) == "string") {
			$this::$options = json_decode($options, true);
		} else {
			throw new \Exception('$options should be array or string.');
		}
	}

	/**
	 * This function escapes the $dataset to be available as an argument to the Command-line Interface.
	 *  
	 * The $dataset is a string value or associative array used in PHP.
	 * If $dataset is a associative array, it is automatically converted to a JSON notation string.
	 * 
	 * @param  $dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available as an argument to the Command-line Interface.
	 * @since  1.2
	 */
	public function toCommandArg($dataset) {
		if (is_null($dataset))  return null;

		$cmd_arg = null;
		if (gettype($dataset) == 'string')  $cmd_arg = $dataset;
		else                                $cmd_arg = json_encode($dataset);

		if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
			$cmd_arg = preg_replace("/\\\"/", "\\\"", $cmd_arg);
			$cmd_arg = preg_replace("/((\\\\)+)\\\\\\\"/", "$1$1\\\"", $cmd_arg);
			$cmd_arg = "\"$cmd_arg\"";
		} else {
			$cmd_arg = escapeshellarg($cmd_arg);
		}

		return $cmd_arg;
	}
}