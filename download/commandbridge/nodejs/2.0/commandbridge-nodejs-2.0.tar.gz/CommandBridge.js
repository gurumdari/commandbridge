/*! CommandBridge/Node.js | https://commandbridge.org */

/**
 * Bridge/Node.js enables you to get results from other languages through the Command-line Interface.
 * 
 * @version 1.0, 2017-02-02  first release for Node.js
 * @version 1.2, 2018-12-14  Option support for ignoring the contents started with warning. / Escaping strings of the commands array.
 * @version 1.3, 2019-03-13  Supports to receive the result of calling remote server's command with CommandBridge via REST API.
 * @version 2.0, 2020-04-14  Remove deprecated APIs.
 * @author Jeasu Kim
 */
module.exports = {

	/**
	 * Bridge/Node.js enables you to get results from other languages through the Command-line Interface.
	 * 
	 * The execution result is passed to the last parameter as callback Function.
	 * The normal result is passed to the first parameter as a string,
	 * and the error is passed to the second parameter as a string.
	 * In order to pass it as a value object, it is possible to pass the result to the JSON notation string in the callee language.
	 * 
	 * Although the dataset is a value object used in JavaScript,
	 * it is automatically converted into a JSON notation string by JSON.stringify function
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
	 * 
	 * @param  {Array} commands     Command list.
	 * @param  {Object} dataset     {@omittable} Data set to be converted to argument.
	 * @param  {String} arg_sep     {@omittable} A delimiter that separates Command and Argument.
	 * @param  {Function} callback  {@nullable} A callback function that takes a normal result string and an error string as parameters.
	 */
	call: function(commands, dataset, argSep, callback) {
		if (typeof dataset == "function") {
			callback = dataset;
			dataset  = null;
			argSep   = null;
		}

		if (typeof argSep == "function") {
			callback = argSep;
			argSep = null;
		}

		if (this.options && this.options.remote) {
			var remoteOptions = this.options.remote;

			var protocol = "http";
			var host     = "localhost";
			var port     = 80;
			var route    = "/remotebridge";

			if (remoteOptions.protocol)  protocol = remoteOptions.protocol;
			if (remoteOptions.host    )  host     = remoteOptions.host;
			if (remoteOptions.port    )  port     = remoteOptions.port;
			if (remoteOptions.route   )  route    = remoteOptions.route;

			var json_data = dataset

			if (dataset && typeof dataset == "object") {
				json_data = JSON.stringify(dataset);
			}

			var params = {
				"commands[]": commands,
				"dataset":    json_data,
				"arg_sep":    argSep,
				"username":   remoteOptions.username,
				"password":   remoteOptions.password
			};

			options4remote = this.options;
			delete options4remote.remote;
			if (options4remote)  params.options = JSON.stringify(options4remote);

			var protocol = require(protocol);

			var request = protocol.request({
				headers: {
					"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
				},
				host:   host,
				port:   port,
				path:   route,
				method: "POST"
			}, function(response) {
				var result = "";

				response.on("data", function (chunk) {
					result += chunk;
				});

				response.on('end', function () {
					var error = null;

					if (result.replace(/\s/g, "").startsWith("{\"error-")) {
						var objError = JSON.parse(result);

						if (Object.prototype.toString.call(objError) == "[object Object]") {
							var errorCode    = objError["error-code"];
							var errorMessage = objError["error-message"];
		
							if (errorCode != null && typeof(errorCode) == "number" && errorMessage != null && typeof(errorMessage) == "string") {
								error  = errorMessage;
								result = null;
							}
						}
					}

					if (callback)  callback(result, error);
				});
			});

			request.on('error', function(e) {
				throw new Error(e.message);
			});

			request.write(this.toFormURL(params));
			request.end();
		} else {
			for (var i = 0; i < commands.length; i++) {
				commands[i] = this.toCommandArg(commands[i]);
			}
	
			var jsonArg = this.toCommandArg(dataset);
			if (jsonArg == "\"\"")  jsonArg = null;
	
			if (jsonArg) {
				if (argSep)  commands.push(argSep);
	
				commands.push(jsonArg);
			}
	
			var command = commands.join(" ");
	
			require('child_process').exec(command, (err, stdout, stderr) => {
				if (stderr && this.options && this.options.ignore && this.options.ignore.type) {
					var ignoreType = this.options.ignore.type;
	
					if (ignoreType == "error") {
						stderr = "";
					} else if (ignoreType == "warning") {
						var ignorePrefix = 'warning';
						var ignoreLine   = 1;
	
						if (this.options.ignore.warning) {
							var ignoreWarning = this.options.ignore.warning;
	
							if (ignoreWarning.prefix && ignoreWarning.prefix != "") {
								ignorePrefix = ignoreWarning.prefix;
							}
	
							if (ignoreWarning.line) {
								var intLine = parseInt(ignoreWarning.line, 10);
	
								if (!isNaN(intLine))  ignoreLine = intLine;
							}
						}
	
						var re = new RegExp("^(" + ignorePrefix + "(.*\\r?\\n){" + ignoreLine.toString() + "})*", "i");
						var replaced_stderr = stderr.replace(re, "");
		
						if (replaced_stderr.trim() == "")  stderr = "";
					}
				}
	
				if (callback)  callback(stdout.replace(/\s+$/, ""), stderr.replace(/\s+$/, ""));
			});
		}
	},

	/**
	 * This function sets the configuration.
	 * 
	 * options is a Object or JSON notation String of the following structure.
	 * 
	 * {
	 *   "remote": {
	 *     "protocol": "{String} @nullable<'http'>",
	 *     "host":     "{String} @nullable<'localhost'>",
	 *     "port":     "{Number} @nullable<80>",
	 *     "route":    "{String} @nullable<'/remotebridge'>",
	 *     "username": "{String}",
	 *     "password": "{String}"
	 *   },
	 *   "ignore": {
	 *     "type": "{String} ['error' or 'warning']",
	 *     "warning": {
	 *       "line":   "{Number} @nullable<1>",
	 *       "prefix": "{String} @nullable<'warning'>"
	 *     }
	 *   }
	 * }
	 * 
	 * If you can not execute the command in Local, when you run RemoteBridge add-on module from Remote Server,
	 * you can receive the result of calling Remote Server's command with CommandBridge via REST API.
	 * At this time, the setting for communication with RemoteBridge can be set to options.remote.
	 * 
	 * If a Warning or Error occurs when calling a command with CommandBridge, an Exception is generated instead of the result.
	 * You can ignore the Warning or Error through options.ignore setting.
	 * If options.ignore.type is "warning",
	 * You can additionally set the options.ignore.warning to include a prefix to be recognized as a warning
	 * and the number of lines to ignore when starting with the letter corresponding to the prefix.
	 * 
	 * @param {Object | String} options  The configuration options.
	 * @since 1.3
	 */
	setConfig: function(options) {
		if (options == null) {
			this.options = null;
		} else if (typeof options == "string") {
			this.options = JSON.parse(options);
		} else {
			this.options = options;
		}
	},

	/**
	 * This function escapes the dataset to be available as an argument to the Command-line Interface.
	 *  
	 * The dataset is a String value or JSON Object used in JavaScript.
	 * If dataset is a JSON Object, it is automatically converted to a JSON notation string.
	 * 
	 * @param  {String | Object} dataset  Data set to be converted to argument.
	 * @return {String} A string that is escaped to be available as an argument to the Command-line Interface.
	 * @since  1.2
	 */
	toCommandArg: function(dataset) {
		if (dataset == null)  return null;

		var args = null;

		if (typeof dataset == "string")  args = dataset;
		else                             args = JSON.stringify(dataset);

		if (process.platform.toUpperCase().startsWith("WIN")) {
			args = args.replace(/\"/g, "\\\"");
			return '"' + args.replace(/((\\)+)\\\"/g, "$1$1\\\"") + '"';
		} else {
			args = "'" + args.replace(/'/g , "'\\''") + "'";
			args = args.replace(/\\'''\\'/g, "\\'\\'");
			args = args.replace(/^''\\''/g , "\\''");
			return args.replace(/'\\'''$/g , "'\\'");
		}
	},

	/**
	 * This function converts JSON object into string of Form URL format.
	 *
	 * @param  {Object} params  JSON object.
	 * @return {String} Form URL format string.
	 * @since  1.3
	 */
	toFormURL: function(params) {
		var formurls = [];

		function getLocalISOString(date) {
			function pad(val, len) {
				val = String(val);
				len = len || 2;
				while (val.length < len) {
					val = "0" + val;
				}
				return val;
			};

			var Z = date.getTimezoneOffset();

			return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate()) + "T" + pad(date.getHours()) + ":" + pad(date.getMinutes()) + ":" + pad(date.getSeconds()) + (Z > 0 ? "-" : "+") + pad(Math.floor(Math.abs(Z) / 60) * 100 + Math.abs(Z) % 60, 4);
		}

		for (var key in params) {
			if (params[key] != null) {
				if (Object.prototype.toString.call(params[key]) == "[object Array]") {
					for (var i = 0; i < params[key].length; i++) {
						var value = params[key][i];

						if (value != null) {
							if (Object.prototype.toString.call(value) == "[object Date]") {
								formurls.push(encodeURIComponent(key) + "=" + encodeURIComponent(getLocalISOString(value)));
							} else {
								if (Object.prototype.toString.call(value) == "[object Object]") {
									value = JSON.stringify(value);
								}

								formurls.push(encodeURIComponent(key) + "=" + encodeURIComponent(value));
							}
						}
					}
				} else if (Object.prototype.toString.call(params[key]) == "[object Date]") {
					formurls.push(encodeURIComponent(key) + "=" + encodeURIComponent(getLocalISOString(params[key])));
				} else {
					var value = params[key];

					if (Object.prototype.toString.call(value) == "[object Object]") {
						value = JSON.stringify(value);
					}

					formurls.push(encodeURIComponent(key) + "=" + encodeURIComponent(value));
				}
			}
		}

		var formurl = formurls.join("&");

		if (formurl == "") {
			return null;
		} else {
			return formurl;
		}
	}
};