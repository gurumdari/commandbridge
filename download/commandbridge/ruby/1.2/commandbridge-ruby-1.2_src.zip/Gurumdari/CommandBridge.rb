# Bridge/Ruby | http://commandbridge.org
require "json"
require "shellwords"

module Gurumdari
	# Bridge/Ruby enables you to get results from other languages through the Command-line Interface.
	# 
	# == Author:
	# Jeasu Kim
	#
	# == Version:
	# 1.0 (2017-02-02):: first release for Ruby
	# 1.2 (2018-12-14):: Option support for ignoring the contents started with warning. / Escaping strings of the commands array.
	class CommandBridge
		@@ignore_conf = {}

		# Bridge/Ruby enables you to get results from other languages through the Command-line Interface.
		# 
		# Since the execution result is a character string, it can be solved by parsing from JSON notation string result as Value Object.
		# 
		# Although the dataset is a value object used in Ruby, it is automatically converted into a JSON notation string
		# and converted into a string that can be used in the Command-line Interface.
		# Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
		# 
		# == Parameters:
		# commands:: Command list.
		# dataset::  Data set to be converted to argument.
		# arg_sep::  A delimiter that separates Command and Argument.
		# 
		# == Returns:
		# String result executed through Command-line Interface.
		def call(commands, dataset = nil, arg_sep = nil)
			json_arg = toCommandArg(dataset)

			if json_arg == "\"\""
				json_arg = nil
			end

			commands.each_with_index do |command, index|
				commands[index] = toCommandArg(command)
			end

			unless json_arg.nil?
				unless arg_sep.nil?
					commands.push(arg_sep)
				end

				commands.push(json_arg)
			end

			commands.push("2>&1")
			command = commands. * " "
			result = ""

			IO.popen(command, "r+") do |pipe|
				result = pipe.read
			end

			result = result

			if $?.success?
				if @@ignore_conf[:prefix] != nil
					warning_regex = '^(' + @@ignore_conf[:prefix] + '(.*\r?\n){' + @@ignore_conf[:line] + '})*'
					result = (result + "\n").gsub!(/#{warning_regex}/i, "")
				end

				result.gsub(/\s+$/, '')
			else
				raise result.gsub(/\s+$/, '')
			end
		end

		# This function ignores the contents started with warning.
		# 
		# It can not be caught because it finds and deletes only the lines starting waring prefix from the result of call function.
		# 
		# == Parameters:
		# line::    The number of lines of warning messages to ignore.
		# prefix::  Warning message prefix ignoring case.
		# 
		# == Since:
		# 1.2
		def ignoreWarningStart(line, prefix = "warning")
			if line.is_a? Integer
				if line > 0
					@@ignore_conf = {
						:prefix => prefix,
						:line   => line.to_s
					}
				end
			else
				raise "line parameter of ignoreWarningStart function should be Integer."
			end
		end

		# This function escapes the dataset to be available as an argument to the Command-line Interface.
		# 
		# The dataset is a String or Hash used in Ruby.
		# If dataset is a Hash, it is automatically converted to a JSON notation string.
		# 
		# This function escapes with a code notation of the unicode that is only available in the JSON notation string.
		# However, since toCommandArg function escapes with the command-line interface escape of the specific OS,
		# toCommandArg can be applied to other string arguments as well as the JSON notation string.
		# 
		# == Parameters:
		# dataset::  Data set to be converted to argument.
		# 
		# == Returns:
		# A string that is escaped to be available as an argument to the Command-line Interface.
		#
		# == Deprecated:
		# As of version 1.2, use toCommandArg instead.
		def toJsonArg(dataset)
			if dataset.nil?
				return nil
			end

			json_arg = ""

			if (dataset.instance_of? String)
				json_arg = dataset
			else
				json_arg = JSON.generate(dataset)
			end

			json_arg = json_arg.gsub(/\\\\([^n|r|t|'|\"|\\])?/, "\\u005c\\1")  # replace \\ [w/o escape prefix] ==> \u005c
			json_arg = json_arg.gsub(/\\\"/, "\\\\\\\\\"")  # replace \" ==> \\"
			json_arg = json_arg.gsub(/\"/, "\\\"")      # replace " ==> \"
			json_arg = json_arg.gsub(/&/, "\\u0026")    # for unix shell & dos command
			json_arg = json_arg.gsub(/!/, "\\u0021")    # for unix shell
			json_arg = json_arg.gsub(/`/, "\\u0060")    # for unix shell
			json_arg = json_arg.gsub(/[$]/, "\\u0024")  # for unix shell
			json_arg = json_arg.gsub(/</, "\\u003c")    # for dos command
			json_arg = json_arg.gsub(/>/, "\\u003e")    # for dos command
			json_arg = json_arg.gsub(/[|]/, "\\u007c")  # for dos command
			"\"" + json_arg + "\""
		end

		# This function escapes the dataset to be available as an argument to the Command-line Interface.
		# 
		# The dataset is a String or Hash used in Ruby.
		# If dataset is a Hash, it is automatically converted to a JSON notation string.
		# 
		# == Parameters:
		# dataset::  Data set to be converted to argument.
		# 
		# == Returns:
		# A string that is escaped to be available as an argument to the Command-line Interface.
		#
		# == Since:
		# 1.2
		def toCommandArg(dataset)
			if dataset.nil?
				return nil
			end

			args = ""

			if (dataset.instance_of? String)
				args = dataset
			else
				args = JSON.generate(dataset)
			end

			if RUBY_PLATFORM =~ /w32/i
				args = args.gsub(/\"/, "\\\"");
				'"' + args.gsub(/((\\)+)\\\"/, "\\1\\1\\\"") + '"'
			else
				Shellwords.escape(args)
			end
		end
	end
end