# CommandBridge/Ruby | https://commandbridge.org
require "json"
require "shellwords"
require 'net/http'

module Gurumdari
	# Bridge/Ruby enables you to get results from other languages through the Command-line Interface.
	# 
	# == Author:
	# Jeasu Kim
	#
	# == Version:
	# 1.0 (2017-02-02):: first release for Ruby
	# 1.2 (2018-12-14):: Option support for ignoring the contents started with warning. / Escaping strings of the commands array.
	# 1.3 (2019-03-13):: Supports to receive the result of calling remote server's command with CommandBridge via REST API.
	class CommandBridge
		@@options = {}

		# Bridge/Ruby enables you to get results from other languages through the Command-line Interface.
		# 
		# Since the execution result is a character string, it can be solved by parsing from JSON notation string result as Value Object.
		# 
		# Although the dataset is a value object used in Ruby, it is automatically converted into a JSON notation string
		# and converted into a string that can be used in the Command-line Interface.
		# Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
		# 
		# == Parameters:
		# commands:: Command list.
		# dataset::  Data set to be converted to argument.
		# arg_sep::  A delimiter that separates Command and Argument.
		# 
		# == Returns:
		# String result executed through Command-line Interface.
		def call(commands, dataset = nil, arg_sep = nil)
			if @@options[:remote].nil?
				json_arg = toCommandArg(dataset)

				if json_arg == "\"\""
					json_arg = nil
				end
	
				commands.each_with_index do |command, index|
					commands[index] = toCommandArg(command)
				end
	
				unless json_arg.nil?
					unless arg_sep.nil?
						commands.push(arg_sep)
					end
	
					commands.push(json_arg)
				end

				if @@options[:ignore] != nil and @@options[:ignore][:type] != nil and @@options[:ignore][:type] == 'error'
					commands.push('2>/dev/null');
					# commands.push('> NUL');
				else
					commands.push('2>&1')
				end

				command = commands. * " "
				result = ""
	
				IO.popen(command, "r+") do |pipe|
					result = pipe.read
				end
	
				result = result
	
				if $?.success?
					if @@options[:ignore] != nil and @@options[:ignore][:type] != nil and @@options[:ignore][:type] == 'warning'
						ignore_prefix = 'warning'
						ignore_line   = 1
	
						if @@options[:ignore][:warning] != nil
							ignore_warning = @@options[:ignore][:warning]
	
							if ignore_warning[:line] != nil and ignore_warning[:line].is_a? Integer
								ignore_line = ignore_warning[:line]
							end
	
							if ignore_warning[:prefix] != nil and ignore_warning[:prefix].is_a? String and ignore_warning[:prefix] != ''
								ignore_prefix = ignore_warning[:prefix]
							end
						end
	
						warning_regex = '^(' + ignore_prefix + '(.*\r?\n){' + ignore_line.to_s + '})*'
						result = (result + "\n").gsub!(/#{warning_regex}/i, "")
					end
	
					result.gsub(/\s+$/, '')
				else
					raise result.gsub(/\s+$/, '')
				end
			else
				remote_options = @@options[:remote]

				protocol = 'http'
				host     = 'localhost'
				port     = 80
				route    = '/remotebridge'
	
				protocol = remote_options[:protocol]  if (remote_options[:protocol] != nil)
				host     = remote_options[:host]      if (remote_options[:host]     != nil)
				port     = remote_options[:port]      if (remote_options[:port]     != nil)
				route    = remote_options[:route]     if (remote_options[:route]    != nil)

				options4remote = @@options
				options4remote.delete(:remote)

				json_data = dataset

				if (dataset != nil and dataset.is_a? Hash)
					json_data = JSON.generate(dataset)
				end

				uri = URI(protocol + '://' + host + ':' + port.to_s + route)
				req = Net::HTTP::Post.new(uri)
				req.set_form_data('commands[]' => commands, 'dataset' => json_data, 'arg_sep' => arg_sep, 'options' => JSON.generate(options4remote), 'username' => remote_options[:username], 'password' => remote_options[:password])

				res = Net::HTTP.start(uri.hostname, uri.port) do |http|
					http.request(req)
				end

				case res

				when Net::HTTPSuccess, Net::HTTPRedirection
					result = res.body

					if (result.gsub(/\s/, '')[0,8] == '{"error-')
						error = JSON.parse(result)

						if error["error-code"] != nil and error["error-message"] != nil
							error_code    = error["error-code"]
							error_message = error["error-message"]

							if error_code.is_a? Integer and error_message.is_a? String
								raise error_message
							end
						end
					end

					result
				else
					raise res.value
				end
			end
		end

		# This function sets the configuration.
		# 
		# options is a Hash type or JSON notation String of the following structure.
		# 
		# {
		#   :remote => {
		#     :protocol => "{str} @nullable<'http'>",
		#     :host     => "{str} @nullable<'localhost'>",
		#     :port     => "{int} @nullable<80>",
		#     :route    => "{str} @nullable<'/remotebridge'>",
		#     :username => "{str}",
		#     :password => "{str}"
		#   },
		#   :ignore => {
		#     :type => "{str} ['error' or 'warning']",
		#     :warning => {
		#       :line   => "{int} @nullable<1>",
		#       :prefix => "{str} @nullable<'warning'>"
		#     }
		#   }
		# }
		# 
		# If you can not execute the command in Local, when you run RemoteBridge add-on module from Remote Server,
		# you can receive the result of calling Remote Server's command with CommandBridge via REST API.
		# At this time, the setting for communication with RemoteBridge can be set to options[:remote].
		# 
		# If a warning or error occurs when calling a command with CommandBridge/Ruby,
		# an exception is generated instead of the result or a warning is output to the result value.
		# You can ignore the warning or error through options[:ignore] setting.
		# If options[:ignore][:type] is 'warning',
		# You can additionally set the options[:ignore][:warning] to include a prefix to be recognized as a warning
		# and the number of lines to ignore when starting with the letter corresponding to the prefix.
		# 
		# CommandBridge/Ruby returns the result of combining stderr and stdout.
		# If options[:ignore][:type] is set to 'error', ignore stderr and return only stdout.
		# If options[:ignore][:type] is set to 'warning',
		# only the lines corresponding to the warning set in the prefix are removed from the result of combining stderr and stdout.
		# 
		# == Parameters:
		# options (dict or str): The configuration options.
		# 
		# == Since:
		# 1.3
		def setConfig(options)
			if options.nil?
				@@options = {}
			else
				if (options.is_a? Hash)
					@@options = options
				elsif (options.is_a? String)
					@@options = JSON.parse(options)
				else
					raise 'options should be Hash or String.'
				end
			end
		end
		
		# This function ignores the contents started with warning.
		# 
		# It can not be caught because it finds and deletes only the lines starting waring prefix from the result of call function.
		# 
		# == Parameters:
		# line::    The number of lines of warning messages to ignore.
		# prefix::  Warning message prefix ignoring case.
		# 
		# == Since:
		# 1.2
		#
		# == Deprecated:
		# As of version 1.3, replaced by setConfig, removed from version 1.4
		def ignoreWarningStart(line, prefix = "warning")
			if line.is_a? Integer
				if line > 0
					@@options = {
						:ignore => {
							:type => "warning",
							:warning => {
								:prefix => prefix,
								:line   => line
							}
						}
					}
				end
			else
				raise 'line parameter of ignoreWarningStart function should be Integer.'
			end
		end

		# This function escapes the dataset to be available as an argument to the Command-line Interface.
		# 
		# The dataset is a String or Hash used in Ruby.
		# If dataset is a Hash, it is automatically converted to a JSON notation string.
		# 
		# This function escapes with a code notation of the unicode that is only available in the JSON notation string.
		# However, since toCommandArg function escapes with the command-line interface escape of the specific OS,
		# toCommandArg can be applied to other string arguments as well as the JSON notation string.
		# 
		# == Parameters:
		# dataset::  Data set to be converted to argument.
		# 
		# == Returns:
		# A string that is escaped to be available as an argument to the Command-line Interface.
		#
		# == Deprecated:
		# As of version 1.2, replaced by toCommandArg, removed from version 1.4
		def toJsonArg(dataset)
			if dataset.nil?
				return nil
			end

			json_arg = ""

			if (dataset.is_a? String)
				json_arg = dataset
			else
				json_arg = JSON.generate(dataset)
			end

			json_arg = json_arg.gsub(/\\\\([^n|r|t|'|\"|\\])?/, "\\u005c\\1")  # replace \\ [w/o escape prefix] ==> \u005c
			json_arg = json_arg.gsub(/\\\"/, "\\\\\\\\\"")  # replace \" ==> \\"
			json_arg = json_arg.gsub(/\"/, "\\\"")      # replace " ==> \"
			json_arg = json_arg.gsub(/&/, "\\u0026")    # for unix shell & dos command
			json_arg = json_arg.gsub(/!/, "\\u0021")    # for unix shell
			json_arg = json_arg.gsub(/`/, "\\u0060")    # for unix shell
			json_arg = json_arg.gsub(/[$]/, "\\u0024")  # for unix shell
			json_arg = json_arg.gsub(/</, "\\u003c")    # for dos command
			json_arg = json_arg.gsub(/>/, "\\u003e")    # for dos command
			json_arg = json_arg.gsub(/[|]/, "\\u007c")  # for dos command
			"\"" + json_arg + "\""
		end

		# This function escapes the dataset to be available as an argument to the Command-line Interface.
		# 
		# The dataset is a String or Hash used in Ruby.
		# If dataset is a Hash, it is automatically converted to a JSON notation string.
		# 
		# == Parameters:
		# dataset::  Data set to be converted to argument.
		# 
		# == Returns:
		# A string that is escaped to be available as an argument to the Command-line Interface.
		#
		# == Since:
		# 1.2
		def toCommandArg(dataset)
			if dataset.nil?
				return nil
			end

			args = ""

			if (dataset.is_a? String)
				args = dataset
			else
				args = JSON.generate(dataset)
			end

			if RUBY_PLATFORM =~ /w32/i
				args = args.gsub(/\"/, "\\\"");
				'"' + args.gsub(/((\\)+)\\\"/, "\\1\\1\\\"") + '"'
			else
				Shellwords.escape(args)
			end
		end
	end
end