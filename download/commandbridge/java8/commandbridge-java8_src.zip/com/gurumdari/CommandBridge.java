/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * http://commandbridge.org
 */
package com.gurumdari;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.gson.Gson;

/**
 * Bridge/Java8 enables you to get results from other languages through the Command-line Interface.
 * 
 * <P>
 * As the javax.json library (JSON Processing API) was decided not to support as an internal module in Java SE,
 * we decided to remove the distinction to display the Java version,
 * Bridge/Java8 compiled with Java 8 and using Gson as an external module for JSON conversion has been deprecated.
 * Bridge/Java, which decided not to display the Java version, was replaced with the javax.json library (JSON Processing API),
 * because Gson does not correctly recognize type in serialized Java value object using Lambda expressions, etc. 
 * 
 * @author Jeasu Kim
 * @deprecated
 */
public class CommandBridge {

	/**
	 * Bridge/Java8 enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands) throws IOException {
		return call(commands, null, null);
	}

	/**
	 * Bridge/Java8 enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a value object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Object dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java8 enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a value object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Object dataset, String argSep) throws IOException {
		String result = "";
		String error  = "";

		String jsonArg = toJsonArgWoQuot(dataset);
		if (jsonArg == "\"\"")  jsonArg = null;

		if (jsonArg != null) {
			if (argSep != null)  commands.add(argSep);

			commands.add(jsonArg);
		}

		InputStream stdout = null;
		InputStream stderr = null;

		try {
			Process process = new ProcessBuilder(commands).start();

			byte[] b = new byte[4096];
			int i;

			// stdout
			stdout = process.getInputStream();
			StringBuffer outBuffer = new StringBuffer("");

			while( (i = stdout.read(b)) != -1)  outBuffer.append(new String(b, 0, i));

			result = outBuffer.toString();

			// stderr
			stderr = process.getErrorStream();
			StringBuffer errBuffer = new StringBuffer("");

			while( (i = stderr.read(b)) != -1)  errBuffer.append(new String(b, 0, i));

			error = errBuffer.toString();

			if (!error.equals(""))  throw new RuntimeException(error.replaceAll("\\s+$", ""));
		} finally {
			if (stdout != null)  stdout.close();
			if (stderr != null)  stderr.close();
		}

		return result.replaceAll("\\s+$", "");
	}

	/**
	 * Bridge/Java8 enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands) throws IOException {
		return call(commands, null, null);
	}

	/**
	 * Bridge/Java8 enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a value object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Object dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java8 enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a value object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Object dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<String>();
		Collections.addAll(commandList, commands);

		return call(commandList, dataset, argSep);
	}

	/**
	 * This method converts the Java Object to a JSON notation string and then escapes the string so that it can be used in the Command-line Interface.
	 * 
	 * @param  dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	 */
	public String toJsonArg(Object dataset) {
		if (dataset == null)  return null;

		String jsonArg = null;
		if (dataset instanceof String)  jsonArg = (String)dataset;
		else                            jsonArg = new Gson().toJson(dataset);

		jsonArg = jsonArg.replaceAll("\\\\\\\\([^n|r|t|'|\"|\\\\])?", "\\\\u005c$1");  // replace \\ [w/o escape prefix] ==> \u005c
		jsonArg = jsonArg.replaceAll("\\\\\\\"", "\\\\\\\\\"");  // replace \" ==> \\"
		jsonArg = jsonArg.replaceAll("\\\"", "\\\\\"");          // replace " ==> \"
		jsonArg = jsonArg.replaceAll("&", "\\\\u0026");    // for unix shell & dos command
		jsonArg = jsonArg.replaceAll("!", "\\\\u0021");    // for unix shell
		jsonArg = jsonArg.replaceAll("`", "\\\\u0060");    // for unix shell
		jsonArg = jsonArg.replaceAll("[$]", "\\\\u0024");  // for unix shell
		jsonArg = jsonArg.replaceAll("<", "\\\\u003c");    // for dos command
		jsonArg = jsonArg.replaceAll(">", "\\\\u003e");    // for dos command
		jsonArg = jsonArg.replaceAll("[|]", "\\\\u007c");  // for dos command

		return "\"" + jsonArg + "\"";
	}

	private String toJsonArgWoQuot(Object dataset) {
		if (dataset == null)  return null;

		String jsonArg = null;
		if (dataset instanceof String)  jsonArg = (String)dataset;
		else                            jsonArg = new Gson().toJson(dataset);

		jsonArg = jsonArg.replaceAll("\\\\\\\\([^n|r|t|'|\"|\\\\])?", "\\\\u005c$1");  // replace \\ [w/o escape prefix] ==> \u005c
		jsonArg = jsonArg.replaceAll("&", "\\\\u0026");    // for unix shell & dos command
		jsonArg = jsonArg.replaceAll("!", "\\\\u0021");    // for unix shell
		jsonArg = jsonArg.replaceAll("`", "\\\\u0060");    // for unix shell
		jsonArg = jsonArg.replaceAll("[$]", "\\\\u0024");  // for unix shell
		jsonArg = jsonArg.replaceAll("<", "\\\\u003c");    // for dos command
		jsonArg = jsonArg.replaceAll(">", "\\\\u003e");    // for dos command
		jsonArg = jsonArg.replaceAll("[|]", "\\\\u007c");  // for dos command

		return jsonArg;
	}
}