/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * https://commandbridge.org
 */
package com.gurumdari;

import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonArrayBuilder;
import jakarta.json.JsonException;
import jakarta.json.JsonNumber;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;
import jakarta.json.JsonReader;
import jakarta.json.JsonString;
import jakarta.json.JsonValue;
import jakarta.json.JsonWriter;
import jakarta.json.JsonWriterFactory;
import jakarta.json.stream.JsonGenerator;

import org.apache.commons.io.IOUtils;

/**
 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
 * 
 * <P>
 * Bridge/Java is using javax.json library (JSON Processing API) as an external module for JSON conversion.
 * So, you should use with the javax.json library (JSON Processing API).
 * 
 * @version 1.0, 2018-09-20  Rebuild using the javax.json library. (JSON Processing API)
 * @version 1.1, 2018-10-10  Additional support for Type not supported by ValueType.
 * @version 1.2, 2018-12-14  Option support for warnings ignore when fetching results from other language with the command-line interface.
 * @version 1.3, 2019-03-13  Supports to receive the result of calling remote server's command with CommandBridge via REST API.
 * @version 2.0, 2020-04-14  Remove deprecated APIs.
 * @version 2.1, 2021-01-15  Supports to prettify JSON notation string.
 * @version 2.2, 2022-03-30  Rebuild using the jakarta.json library.
 * @version 2.3, 2023-02-27  Ability to change working directory.
 * @author  Jeasu Kim
 */
public class CommandBridge {
	private Map<String, Object> options = new HashMap<>();
	private File directory = null;

	/**
	 * This method sets the working directory.
	 * 
	 * @param  workingDirectory  working directory to change
	 */
	public void setDirectory(File workingDirectory) {
		this.directory = workingDirectory;
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands) throws IOException {
		return call(commands, (String)null, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, String dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Map<String, ?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Collection<?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, String dataset, String argSep) throws IOException {
		return callWithCommand(commands, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Map<String, ?> dataset, String argSep) throws IOException {
		return callWithCommand(commands, toJson(dataset), argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Collection<?> dataset, String argSep) throws IOException {
		return callWithCommand(commands, toJson(dataset), argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands) throws IOException {
		return call(commands, (String)null, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, String dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Map<String, ?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Collection<?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, String dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callWithCommand(commandList, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Map<String, ?> dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callWithCommand(commandList, toJson(dataset), argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Collection<?> dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callWithCommand(commandList, toJson(dataset), argSep);
	}

	private String callWithCommand(List<String> commands, String jsonArg, String argSep) throws IOException {
		@SuppressWarnings("unchecked")
		Map<String, Object> remoteOptions = (Map<String, Object>)this.options.get("remote");

		if (jsonArg == "")  jsonArg = null;

		if (remoteOptions == null) {
			String result = "";
			String error  = "";

			if (jsonArg != null) {
				if (argSep != null)  commands.add(argSep);

				commands.add(jsonArg);
			}

			InputStream stdout = null;
			InputStream stderr = null;

			try {
				ProcessBuilder builder = new ProcessBuilder(commands);
				if (directory != null)  builder.directory(directory);
				// builder.redirectErrorStream(true);
				Process process = builder.start();

				byte[] b = new byte[4096];
				int i;

				// stdout
				stdout = process.getInputStream();
				StringBuffer outBuffer = new StringBuffer("");

				while( (i = stdout.read(b)) != -1)  outBuffer.append(new String(b, 0, i));

				result = outBuffer.toString();

				// stderr
				stderr = process.getErrorStream();
				StringBuffer errBuffer = new StringBuffer("");

				while( (i = stderr.read(b)) != -1)  errBuffer.append(new String(b, 0, i));

				error = errBuffer.toString();

				if (!error.equals("")) {
					@SuppressWarnings("unchecked")
					Map<String, Object> ignoreOptions = (Map<String, Object>)this.options.get("ignore");
					if (ignoreOptions != null) {
						String ignoreType = (String)ignoreOptions.get("type");

						if ("error".equals(ignoreType)) {
							error = "";
						} else if ("warning".equals(ignoreType)) {
							String ignorePrefix = "warning";
							int    ignoreLine   = 1;

							@SuppressWarnings("unchecked")
							Map<String, Object> warningOptions = (Map<String, Object>)ignoreOptions.get("warning");

							if (warningOptions != null) {
								Object objPrefix = warningOptions.get("prefix");
								Object objLine   = warningOptions.get("line");

								if (objPrefix != null && objPrefix instanceof String && !((String)objPrefix).equals("")) {
									ignorePrefix = (String)objPrefix;
								}

								if (objLine != null && objLine instanceof Integer) {
									ignoreLine = (int)objLine;
								}
							}

							String replacedError = (error + "\n").replaceAll("(?i)^(" + ignorePrefix + "(.*\\r?\\n){" + ignoreLine +"})*", "").trim();
							// If ErrorStream contains anything other than Warning, it displays all the contents before substitution.
							if (replacedError.equals(""))  error = "";
						}
					}
				}

				if (!error.equals(""))  throw new RuntimeException(error.replaceAll("\\s+$", ""));
			} finally {
				if (stdout != null)  stdout.close();
				if (stderr != null)  stderr.close();
			}

			return result.replaceAll("\\s+$", "");
		} else {
			String protocol = "http";
			String host     = "localhost";
			int    port     = 80;
			String route    = "/remotebridge";

			Object objProtocol = remoteOptions.get("protocol");
			Object objHost     = remoteOptions.get("host");
			Object objPort     = remoteOptions.get("port");
			Object objRoute    = remoteOptions.get("route");

			if (objProtocol != null)  protocol = (String)objProtocol;
			if (objHost     != null)  host     = (String)objHost;
			if (objPort     != null)  port     = (int)objPort;
			if (objRoute    != null)  route    = (String)objRoute;

			Map<String, Object> params = new HashMap<>();
			params.put("commands[]", commands);
			params.put("username"  , remoteOptions.get("username"));
			params.put("password"  , remoteOptions.get("password"));

			if (jsonArg != null)  params.put("dataset", jsonArg);
			if (argSep  != null)  params.put("arg_sep", argSep);

			this.options.remove("remote");
			params.put("options", toJson(this.options));

			URL url = new URL(String.format("%s://%s:%d%s", protocol, host, port, route));

			HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
			urlConn.setRequestMethod("POST");
			urlConn.setDoOutput(true);
			urlConn.setDoInput(true);
			urlConn.setUseCaches(false);
			urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");

			DataOutputStream  output = new DataOutputStream(urlConn.getOutputStream());
			output.writeBytes(toFormURL(params));

			String result = IOUtils.toString(urlConn.getInputStream(), "UTF-8");

			if (result != null && result.replaceAll("\\s", "").startsWith("{\"error-")) {
				Object objError = fromJson(result);

				if (objError instanceof Map) {
					@SuppressWarnings("unchecked")
					Map<String, Object> mapError = (Map<String, Object>)objError;
					Object errorCode    = mapError.get("error-code");
					Object errorMessage = mapError.get("error-message");

					if (errorCode != null && errorCode instanceof Integer && errorMessage != null && errorMessage instanceof String) {
						throw new RuntimeException((String)errorMessage);
					}
				}
			}

			return result;
		}
	}

	/**
	 * This method sets the configuration.
	 * 
	 * options is a Map Object of the following structure.
	 * 
	 * Map<String, Object> options = new HashMap<String, Object>() {
	 *   private static final long serialVersionUID = 1L;
	 *   {
	 *     put("remote", new HashMap<String, Object>() {
	 *       private static final long serialVersionUID = 1L;
	 *       {
	 *         put("protocol", "{String} @nullable<'http'>");
	 *         put("host"    , "{String} @nullable<'localhost'>");
	 *         put("port"    , "{int} @nullable<80>");
	 *         put("route"   , "{String} @nullable<'/remotebridge'>");
	 *         put("username", "{string}");
	 *         put("password", "{string}");
	 *       }
	 *     });
	 *     put("ignore", new HashMap<String, Object>() {
	 *       private static final long serialVersionUID = 1L;
	 *       {
	 *         put("type", "{String} ['error' or 'warning']");
	 *         put("warning", new HashMap<String, Object>() {
	 *           private static final long serialVersionUID = 1L;
	 *           {
	 *             put("line", "{int} @nullable<1>");
	 *             put("prefix", "{string} @nullable<'warning'>");
	 *           }
	 *         });
	 *       }
	 *     });
	 *   }
	 * };
	 * 
	 * If you can not execute the command in Local, when you run RemoteBridge add-on module from Remote Server,
	 * you can receive the result of calling Remote Server's command with CommandBridge via REST API.
	 * At this time, the setting for communication with RemoteBridge can be set to options.get("remote").
	 * 
	 * If a Warning or Error occurs when calling a command with CommandBridge, an Exception is generated instead of the result.
	 * You can ignore the Warning or Error through options.get("ignore") setting.
	 * If ((Map)options.get("ignore")).get("type") is "warning",
	 * You can additionally set the ((Map)options.get("ignore")).get("warning") to include a prefix to be recognized as a warning
	 * and the number of lines to ignore when starting with the letter corresponding to the prefix.
	 * 
	 * @param options  The configuration options.
	 * @since 1.3
	 */
	public void setConfig(Map<String, Object> options) {
		if (options == null) {
			this.options = new HashMap<>();
		} else {
			this.options = options;
		}
	}

	/**
	 * This method sets the configuration.
	 * 
	 * options is a JSON notation String of the following structure.
	 * 
	 * {
	 *   "remote": {
	 *     "protocol": "{String} @nullable<'http'>",
	 *     "host":     "{String} @nullable<'localhost'>",
	 *     "port":     "{Number} @nullable<80>",
	 *     "route":    "{String} @nullable<'/remotebridge'>",
	 *     "username": "{String}",
	 *     "password": "{String}"
	 *   },
	 *   "ignore": {
	 *     "type": "{String} ['error' or 'warning']",
	 *     "warning": {
	 *       "line":   "{Number} @nullable<1>",
	 *       "prefix": "{String} @nullable<'warning'>"
	 *     }
	 *   }
	 * }
	 * 
	 * If you can not execute the command in Local, when you run RemoteBridge add-on module from Remote Server,
	 * you can receive the result of calling Remote Server's command with CommandBridge via REST API.
	 * At this time, the setting for communication with RemoteBridge can be set to options.get("remote").
	 * 
	 * If a Warning or Error occurs when calling a command with CommandBridge, an Exception is generated instead of the result.
	 * You can ignore the Warning or Error through options.get("ignore") setting.
	 * If options.ignore.type is "warning",
	 * You can additionally set the options.ignore.warning to include a prefix to be recognized as a warning
	 * and the number of lines to ignore when starting with the letter corresponding to the prefix.
	 * 
	 * @param options  The configuration options.
	 * @since 1.3
	 */
	public void setConfig(String options) {
		if (options == null) {
			this.options = new HashMap<>();
		} else {
			this.options = fromJson(options);
		}
	}

	/**
	 * This method converts {@link Map} object to a JSON notation string.
	 * 
	 * @param   dataset  {@link Map} object to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(Map<String, ?> dataset) {
		if (dataset == null)  return "null";

		// JsonObject object = Json.createObjectBuilder(dataset).build();
		// return object.toString();

		return getJsonObject(dataset).toString();
	}

	/**
	 * This method converts {@link Collection} object to a JSON notation string.
	 * 
	 * @param   dataset  {@link Collection} object to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(Collection<?> dataset) {
		if (dataset == null)  return "null";

		// JsonArray array = Json.createArrayBuilder(dataset).build();
		// return array.toString();

		return getJsonArray(dataset).toString();
	}

	/**
	 * This method converts {@link String} value to a JSON notation string.
	 * 
	 * @param   value  {@link String} value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(String value) {
		if (value == null)  return "null";

		JsonString string = Json.createValue(value);
		return string.toString();
	}

	/**
	 * This method converts {@link Date} value to a JSON notation string.
	 * 
	 * @param   value  {@link Date} value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 * @since   2.1
	 */
	public String toJson(Date value) {
		if (value == null)  return "null";

		String stringValue = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format((Date)value);

		JsonString string = Json.createValue(stringValue);
		return string.toString();
	}

	/**
	 * This method converts double value to a JSON notation string.
	 * 
	 * @param   value  double value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(double value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts long value to a JSON notation string.
	 * 
	 * @param   value  long value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(long value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts int value to a JSON notation string.
	 * 
	 * @param   value  int value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(int value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts boolean value to a JSON notation string.
	 * 
	 * @param   value  boolean value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(boolean value) {
		return String.valueOf(value);
	}

	/**
	 * This method reformats the JSON notation string prettily.
	 * 
	 * @param   json  JSON notation string to be reformatted prettily.
	 * @return  Pretty reformatted JSON notation string.
	 * @since   2.1
	 */
	public String prettifyJson(String json) {
		if (json == null || json.trim().equals(""))  return json;

		try {
			Map<String, Object> config = new HashMap<>();
			config.put(JsonGenerator.PRETTY_PRINTING, true);

			StringWriter writer = new StringWriter();
			JsonWriterFactory factory = Json.createWriterFactory(config);
			JsonWriter jsonWriter = factory.createWriter(writer);

			JsonReader reader = Json.createReader(new StringReader(json));
			jsonWriter.write(reader.read());
			jsonWriter.close();
			
			return writer.toString().trim();
		} catch(JsonException e) {
			return json;
		}
	}

	private JsonObject getJsonObject(Map<String, ?> dataset) {
		JsonObjectBuilder builder = Json.createObjectBuilder();

		try {
			Set<String> keySet = dataset.keySet();
			for (String key : keySet) {
				builder.add(key, getJsonValue(dataset.get(key)));
			}
		} catch(ClassCastException e) {
			throw new IllegalArgumentException(String.format("The key of the map should be a String. (%s)", e.getMessage()));
		}

		return builder.build();
	}

	private JsonArray getJsonArray(Collection<?> dataset) {
		JsonArrayBuilder builder = Json.createArrayBuilder();

		for (Object data : dataset) {
			builder.add(getJsonValue(data));
		}

		return builder.build();
	}

	private JsonValue getJsonValue(Object object) {
		if (object == null)  return JsonValue.NULL;

		if (object instanceof Map) {
			@SuppressWarnings("unchecked")
			Map<String, Object> mapValue = (Map<String, Object>)object;
			return getJsonObject(mapValue);
		} else if (object instanceof Map[]) {
			@SuppressWarnings("unchecked")
			Map<String, Object>[] values = (Map<String, Object>[])object;
			return getJsonArray(Arrays.asList(values));
		}
		else if (object instanceof Collection   )   return getJsonArray((Collection<?>)object);
		else if (object instanceof String       )   return Json.createValue((String)object);
		else if (object instanceof StringBuffer )   return Json.createValue(((StringBuffer)object).toString());
		else if (object instanceof StringBuilder)   return Json.createValue(((StringBuilder)object).toString());
		else if (object instanceof Boolean      )   return ((Boolean)object ? JsonValue.TRUE : JsonValue.FALSE);
		else if (object instanceof BigDecimal   )   return Json.createValue((BigDecimal)object);
		else if (object instanceof BigInteger   )   return Json.createValue((BigInteger)object);
		else if (object instanceof Double       )   return Json.createValue((double)object);
		else if (object instanceof Integer      )   return Json.createValue((int)object);
		else if (object instanceof Long         )   return Json.createValue((long)object);
		else if (object instanceof Byte         )   return Json.createValue((int)(byte)object);
		else if (object instanceof Short        )   return Json.createValue((int)(short)object);
		else if (object instanceof Character    )   return Json.createValue(String.valueOf((char)object));
		else if (object instanceof Date         )   return Json.createValue(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format((Date)object));
		else if (object instanceof Float        )   return Json.createValue(Double.valueOf(String.valueOf((float)object)));
		else if (object instanceof String[]     ) { String[]     values = (String[])object;      return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Boolean[]    ) { Boolean[]    values = (Boolean[])object;     return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof BigDecimal[] ) { BigDecimal[] values = (BigDecimal[])object;  return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof BigInteger[] ) { BigInteger[] values = (BigInteger[])object;  return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Double[]     ) { Double[]     values = (Double[])object;      return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Integer[]    ) { Integer[]    values = (Integer[])object;     return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Long[]       ) { Long[]       values = (Long[])object;        return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Byte[]       ) { Byte[]       values = (Byte[])object;        return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Short[]      ) { Short[]      values = (Short[])object;       return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Character[]  ) { Character[]  values = (Character[])object;   return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Date[]       ) { Date[]       values = (Date[])object;        return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Float[]) {
			Float[] values = (Float[])object;
			List<Double> valueList = new ArrayList<>();

			for (float value : values) {
				valueList.add(Double.valueOf(String.valueOf(value)));
			}

			return getJsonArray(valueList);
		} else if (object instanceof double[]) {
			Double[] values = Arrays.stream((double[])object).boxed().toArray(Double[]::new);
			return getJsonArray(Arrays.asList(values));
		} else if (object instanceof int[]) {
			Integer[] values = Arrays.stream((int[])object).boxed().toArray(Integer[]::new);
			return getJsonArray(Arrays.asList(values));
		} else if (object instanceof long[]) {
			Long[] values = Arrays.stream((long[])object).boxed().toArray(Long[]::new);
			return getJsonArray(Arrays.asList(values));
		} else if (object instanceof float[]) {
			float[] values = (float[])object;
			List<Double> valueList = new ArrayList<>();

			for (float value : values) {
				valueList.add(Double.valueOf(String.valueOf(value)));
			}

			return getJsonArray(valueList);
		} else if (object instanceof boolean[]) {
			boolean[] values = (boolean[])object;
			List<Boolean> valueList = new ArrayList<>();

			for (boolean value : values) {
				valueList.add(Boolean.valueOf(value));
			}

			return getJsonArray(valueList);
		} else if (object instanceof byte[]) {
			byte[] values = (byte[])object;
			List<Byte> valueList = new ArrayList<>();

			for (byte value : values) {
				valueList.add(Byte.valueOf(value));
			}

			return getJsonArray(valueList);
		} else if (object instanceof short[]) {
			short[] values = (short[])object;
			List<Short> valueList = new ArrayList<>();

			for (short value : values) {
				valueList.add(Short.valueOf(value));
			}

			return getJsonArray(valueList);
		} else if (object instanceof char[]) {
			char[] values = (char[])object;
			List<Character> valueList = new ArrayList<>();

			for (char value : values) {
				valueList.add(Character.valueOf(value));
			}

			return getJsonArray(valueList);
		}

		throw new IllegalArgumentException(String.format("Type %s is not supported.", object.getClass()));
	}

	/**
	 * The JSON notation string is converted to {@link Map}, {@link List}, {@link String}, {@link Boolean}, {@link Integer}, {@link Long}, or {@link Double} used in Java.
	 * 
	 * @param   json  JSON notation string to be converted to a object used in Java.
	 * @return  A object used in Java.
	 */
	public <T> T fromJson(String json) {
		return fromJson(json, false);
	}


	/**
	 * The JSON notation string is converted to {@link Map}, {@link List}, {@link String}, {@link Boolean}, {@link Integer}, {@link Long}, or {@link Double} used in Java.
	 * 
	 * <P>
	 * If stringValueOnly is true, the values of the JSON is converted to a string value only.
	 * 
	 * @param   stringValueOnly  Whether to convert values to strings only.
	 * @param   json  JSON notation string to be converted to a object used in Java.
	 * @return  A object used in Java.
	 * @since   1.1
	 */
	@SuppressWarnings("unchecked")
	public <T> T fromJson(String json, boolean stringValueOnly) {
		if (json == null || json.trim().equals("")) {
			return null;
		}

		JsonReader reader = Json.createReader(new StringReader(json));
		return (T)parseJsonValue(reader.readValue(), stringValueOnly);
	}

	private Map<String, Object> parseJsonObject(JsonObject object, boolean stringValueOnly) {
		Map<String, Object> map = new HashMap<>();

		Set<String> keySet = object.keySet();
		for (String key : keySet) {
			map.put(key, parseJsonValue(object.get(key), stringValueOnly));
		}

		return map;
	}

	private List<?> parseJsonArray(JsonArray array, boolean stringValueOnly) {
		List<Object> list = new ArrayList<>();

		for (JsonValue value : array) {
			list.add(parseJsonValue(value, stringValueOnly));
		}

		return list;
	}

	private Object parseJsonValue(JsonValue value, boolean stringValueOnly) {
		switch (value.getValueType()) {
			case NULL:
				return null;
			case TRUE:
				return stringValueOnly ? "true" : true;
			case FALSE:
				return stringValueOnly ? "false" : false;
			case STRING:
				return ((JsonString)value).getString();
			case NUMBER:
				JsonNumber number = (JsonNumber)value;

				if (stringValueOnly) {
					return number.toString();
				} else {
					long   longValue   = number.longValue();
					double doubleValue = number.doubleValue();
	
					if (Math.ceil(Math.abs(doubleValue)) == Math.abs(longValue)) {
						if (longValue >= -2147483648 && longValue <= 2147483647) {
							return number.intValue();
						} else  {
							return longValue;
						}
					} else {
						return doubleValue;
					}
				}
			case ARRAY:
				return parseJsonArray((JsonArray)value, stringValueOnly);
			case OBJECT:
				return parseJsonObject((JsonObject)value, stringValueOnly);
			default:
				return null;
		}
	}

	/**
	 * This method converts JSON object into string of Form URL format.
	 * 
	 * @param  params  Map object.
	 * @return Form URL format string.
	 * @throws UnsupportedEncodingException  When UTF-8 is unknown.
	 * @since 1.3
	 */
	@SuppressWarnings("unchecked")
	public String toFormURL(Map<String, Object> params) throws UnsupportedEncodingException {
		Set<String> keySet = params.keySet();

		StringBuffer paramBuffer = new StringBuffer();

		for (String key : keySet) {
			Object objValue = params.get(key);

			if (objValue != null) {
				if (objValue instanceof Collection) {
					Collection<Object> values = (Collection<Object>)objValue;

					for (Object value : values) {
						if (value != null) {
							if (value instanceof Map) {
								paramBuffer.append("&").append(URLEncoder.encode(key, "UTF-8")).append("=").append(URLEncoder.encode(toJson((Map<String, Object>)value), "UTF-8"));
							} else if (value instanceof Date) {
								paramBuffer.append("&").append(URLEncoder.encode(key, "UTF-8")).append("=").append(URLEncoder.encode(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format((Date)value), "UTF-8"));
							} else {
								paramBuffer.append("&").append(URLEncoder.encode(key, "UTF-8")).append("=").append(URLEncoder.encode(String.valueOf(value), "UTF-8"));
							}
						}
					}
				} else if (objValue instanceof Map) {
					paramBuffer.append("&").append(URLEncoder.encode(key, "UTF-8")).append("=").append(URLEncoder.encode(toJson((Map<String, Object>)objValue), "UTF-8"));
				} else if (objValue instanceof Date) {
					paramBuffer.append("&").append(URLEncoder.encode(key, "UTF-8")).append("=").append(URLEncoder.encode(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format((Date)objValue), "UTF-8"));
				} else {
					paramBuffer.append("&").append(URLEncoder.encode(key, "UTF-8")).append("=").append(URLEncoder.encode(String.valueOf(objValue), "UTF-8"));
				}
			}
		}

		String paramValue = paramBuffer.toString();

		if (paramValue.equals("")) {
			return null;
		} else {
			return paramValue.substring(1);
		}
	}
}