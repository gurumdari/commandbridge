/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * http://commandbridge.org
 */
package com.gurumdari;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonException;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.json.JsonValue;

/**
 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
 * 
 * <P>
 * Bridge/Java is using javax.json library (JSON Processing API) as an external module for JSON conversion.
 * So, you should use with the javax.json library (JSON Processing API).
 * 
 * @version 1.0, 2018-09-20  Rebuild using the javax.json library (JSON Processing API)
 * @author  Jeasu Kim
 */
public class CommandBridge {

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands) throws IOException {
		return call(commands, (String)null, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, String dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Map<String, Object> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link List} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, List<Object> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, String dataset, String argSep) throws IOException {
		return callObject(commands, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Map<String, Object> dataset, String argSep) throws IOException {
		return callObject(commands, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link List} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, List<Object> dataset, String argSep) throws IOException {
		return callObject(commands, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands) throws IOException {
		return call(commands, (String)null, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, String dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Map<String, Object> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link List} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, List<Object> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, String dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callObject(commandList, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Map<String, Object> dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callObject(commandList, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link List} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, List<Object> dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callObject(commandList, dataset, argSep);
	}

	private String callObject(List<String> commands, Object dataset, String argSep) throws IOException {
		String result = "";
		String error  = "";

		String jsonArg = toJsonArgWoQuot(dataset);
		if (jsonArg == "\"\"")  jsonArg = null;

		if (jsonArg != null) {
			if (argSep != null)  commands.add(argSep);

			commands.add(jsonArg);
		}

		InputStream stdout = null;
		InputStream stderr = null;

		try {
			Process process = new ProcessBuilder(commands).start();

			byte[] b = new byte[4096];
			int i;

			// stdout
			stdout = process.getInputStream();
			StringBuffer outBuffer = new StringBuffer("");

			while( (i = stdout.read(b)) != -1)  outBuffer.append(new String(b, 0, i));

			result = outBuffer.toString();

			// stderr
			stderr = process.getErrorStream();
			StringBuffer errBuffer = new StringBuffer("");

			while( (i = stderr.read(b)) != -1)  errBuffer.append(new String(b, 0, i));

			error = errBuffer.toString();

			if (!error.equals(""))  throw new RuntimeException(error.replaceAll("\\s+$", ""));
		} finally {
			if (stdout != null)  stdout.close();
			if (stderr != null)  stderr.close();
		}

		return result.replaceAll("\\s+$", "");
	}

	/**
	 * This method converts the {@link Map} object used in Java to a JSON notation string
	 * and then escapes the string so that it can be used in the Command-line Interface.
	 * 
	 * @param  dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	 */
	public String toJsonArg(Map<String, Object> dataset) {
		if (dataset == null)  return null;

		return toJsonArg(toJson(dataset));
	}

	/**
	 * This method converts the {@link List} object used in Java to a JSON notation string
	 * and then escapes the string so that it can be used in the Command-line Interface.
	 * 
	 * @param  dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	 */
	public String toJsonArg(List<Object> dataset) {
		if (dataset == null)  return null;

		return toJsonArg(toJson(dataset));
	}

	/**
	 * This method escapes the string so that it can be used in the Command-line Interface.
	 * 
	 * @param  json  JSON notation string to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface.
	 */
	public String toJsonArg(String json) {
		if (json == null)  return null;

		json = json.replaceAll("\\\\\\\\([^n|r|t|'|\"|\\\\])?", "\\\\u005c$1");  // replace \\ [w/o escape prefix] ==> \u005c
		json = json.replaceAll("\\\\\\\"", "\\\\\\\\\"");  // replace \" ==> \\"
		json = json.replaceAll("\\\"", "\\\\\"");          // replace " ==> \"
		json = json.replaceAll("&", "\\\\u0026");    // for unix shell & dos command
		json = json.replaceAll("!", "\\\\u0021");    // for unix shell
		json = json.replaceAll("`", "\\\\u0060");    // for unix shell
		json = json.replaceAll("[$]", "\\\\u0024");  // for unix shell
		json = json.replaceAll("<", "\\\\u003c");    // for dos command
		json = json.replaceAll(">", "\\\\u003e");    // for dos command
		json = json.replaceAll("[|]", "\\\\u007c");  // for dos command

		return "\"" + json + "\"";
	}

	@SuppressWarnings("unchecked")
	private String toJsonArgWoQuot(Object dataset) {
		if (dataset == null)  return null;

		String jsonArg = null;
		if      (dataset instanceof String)  jsonArg = (String)dataset;
		else if (dataset instanceof Map   )  jsonArg = toJson((Map<String, Object>)dataset);
		else if (dataset instanceof List  )  jsonArg = toJson((List<Object>)dataset);

		jsonArg = jsonArg.replaceAll("\\\\\\\\([^n|r|t|'|\"|\\\\])?", "\\\\u005c$1");  // replace \\ [w/o escape prefix] ==> \u005c
		jsonArg = jsonArg.replaceAll("&", "\\\\u0026");    // for unix shell & dos command
		jsonArg = jsonArg.replaceAll("!", "\\\\u0021");    // for unix shell
		jsonArg = jsonArg.replaceAll("`", "\\\\u0060");    // for unix shell
		jsonArg = jsonArg.replaceAll("[$]", "\\\\u0024");  // for unix shell
		jsonArg = jsonArg.replaceAll("<", "\\\\u003c");    // for dos command
		jsonArg = jsonArg.replaceAll(">", "\\\\u003e");    // for dos command
		jsonArg = jsonArg.replaceAll("[|]", "\\\\u007c");  // for dos command

		return jsonArg;
	}

	/**
	 * This method converts {@link Map} object to A JSON notation string.
	 * 
	 * @param   dataset  {@link Map} object to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(Map<String, ?> dataset) {
		if (dataset == null)  return "null";

		@SuppressWarnings("unchecked")
		JsonObject object = Json.createObjectBuilder((Map<String, Object>)dataset).build();
		return object.toString();
	}

	/**
	 * This method converts {@link List} object to A JSON notation string.
	 * 
	 * @param   dataset  {@link List} object to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(List<?> dataset) {
		if (dataset == null)  return "null";

		JsonArray array = Json.createArrayBuilder(dataset).build();
		return array.toString();
	}

	/**
	 * This method converts {@link String} value to A JSON notation string.
	 * 
	 * @param   value  {@link String} value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(String value) {
		if (value == null)  return "null";

		JsonString string = Json.createValue(value);
		return string.toString();
	}

	/**
	 * This method converts double value to A JSON notation string.
	 * 
	 * @param   value  double value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(double value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts long value to A JSON notation string.
	 * 
	 * @param   value  long value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(long value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts int value to A JSON notation string.
	 * 
	 * @param   value  int value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(int value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts boolean value to A JSON notation string.
	 * 
	 * @param   value  boolean value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(boolean value) {
		return String.valueOf(value);
	}

	/**
	 * The JSON notation string is converted to {@link Map}, {@link List}, {@link String}, {@link Boolean}, {@link Integer}, {@link Long}, or {@link Double} used in Java.
	 * 
	 * @param   json  JSON notation string to be converted to a object used in Java.
	 * @return A object used in Java.
	 */
	public Object fromJson(String json) {
		JsonReader reader = Json.createReader(new StringReader(json));
		return parseJsonValue(reader.readValue());
	}

	private Map<String, ?> parseJsonObject(JsonObject object) throws JsonException {
		Map<String, Object> map = new HashMap<>();

		Iterator<String> keysItr = object.keySet().iterator();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			map.put(key, parseJsonValue(object.get(key)));
		}

		return map;
	}

	private List<?> parseJsonArray(JsonArray array) {
		List<Object> list = new ArrayList<>();

		for (JsonValue value : array) {
			list.add(parseJsonValue(value));
		}

		return list;
	}

	private Object parseJsonValue(JsonValue value) {
		switch (value.getValueType()) {
			case NULL:
				return null;
			case TRUE:
				return true;
			case FALSE:
				return false;
			case STRING:
				return ((JsonString)value).getString();
			case NUMBER:
				JsonNumber number = (JsonNumber)value;
				long   longValue   = number.longValue();
				double doubleValue = number.doubleValue();

				if (Math.ceil(Math.abs(doubleValue)) == Math.abs(longValue)) {
					if (longValue >= -2147483648 && longValue <= 2147483647) {
						return number.intValue();
					} else  {
						return longValue;
					}
				} else {
					return doubleValue;
				}
			case ARRAY:
				return parseJsonArray((JsonArray)value);
			case OBJECT:
				return parseJsonObject((JsonObject)value);
			default:
				return null;
		}
	}
}