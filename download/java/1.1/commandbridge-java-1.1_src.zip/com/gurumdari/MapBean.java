package com.gurumdari;

import java.util.HashMap;
import java.util.Map;

public class MapBean {
	public <T> Map<String, T> getFormParam() {
		Map<String, Object> formParam = new HashMap<>();

		formParam.put("key1", "value1");
		formParam.put("key2", new String[] {"value1-1", "value1-2"});

		return (Map<String, T>) formParam;
	}
}