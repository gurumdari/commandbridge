/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * http://commandbridge.org
 */
package com.gurumdari;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.json.JsonValue;

/**
 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
 * 
 * <P>
 * Bridge/Java is using javax.json library (JSON Processing API) as an external module for JSON conversion.
 * So, you should use with the javax.json library (JSON Processing API).
 * 
 * @version 1.0, 2018-09-20  Rebuild using the javax.json library (JSON Processing API)
 * @version 1.1, 2018-10-10  Additional support for Type not supported by ValueType
 * @version 1.2, 2018-12-14  Option support for warnings ignore when fetching results from other language with the command-line interface.
 * @author  Jeasu Kim
 */
public class CommandBridge {
	private Map<String, String> ignoreConf = new HashMap<>();

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands) throws IOException {
		return call(commands, (String)null, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, String dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Map<String, ?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Collection<?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, String dataset, String argSep) throws IOException {
		return callWithCommand(commands, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Map<String, ?> dataset, String argSep) throws IOException {
		return callWithCommand(commands, toJson(dataset), argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(List<String> commands, Collection<?> dataset, String argSep) throws IOException {
		return callWithCommand(commands, toJson(dataset), argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * @param  commands  Command list.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands) throws IOException {
		return call(commands, (String)null, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, String dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Map<String, ?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Collection<?> dataset) throws IOException {
		return call(commands, dataset, null);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * The JSON notation string, dataset, is converted to a string that is escaped to use in the Command-line Interface.
	 * The argument should be parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   JSON notation string to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, String dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callWithCommand(commandList, dataset, argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Map} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Map<String, ?> dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callWithCommand(commandList, toJson(dataset), argSep);
	}

	/**
	 * Bridge/Java enables you to get results from other languages through the Command-line Interface.
	 * 
	 * <P>
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * <P>
	 * Although the dataset is a {@link Collection} object used in Java, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string as value object in the callee language.
	 * 
	 * @param  commands  Command list.
	 * @param  dataset   Data set to be converted to argument.
	 * @param  argSep    A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 * @throws IOException  When it can not be executed with Command-line Interface.
	 */
	public String call(String[] commands, Collection<?> dataset, String argSep) throws IOException {
		List<String> commandList = new ArrayList<>();
		Collections.addAll(commandList, commands);

		return callWithCommand(commandList, toJson(dataset), argSep);
	}

	private String callWithCommand(List<String> commands, String jsonArg, String argSep) throws IOException {
		String result  = "";
		String error   = "";

		if (jsonArg == "")  jsonArg = null;

		if (jsonArg != null) {
			if (argSep != null)  commands.add(argSep);

			commands.add(jsonArg);
		}

		InputStream stdout = null;
		InputStream stderr = null;

		try {
			ProcessBuilder builder = new ProcessBuilder(commands);
			// builder.redirectErrorStream(true);
			Process process = builder.start();

			byte[] b = new byte[4096];
			int i;

			// stdout
			stdout = process.getInputStream();
			StringBuffer outBuffer = new StringBuffer("");

			while( (i = stdout.read(b)) != -1)  outBuffer.append(new String(b, 0, i));

			result = outBuffer.toString();

			// stderr
			stderr = process.getErrorStream();
			StringBuffer errBuffer = new StringBuffer("");

			while( (i = stderr.read(b)) != -1)  errBuffer.append(new String(b, 0, i));

			error = errBuffer.toString();

			if (!error.equals("")) {
				String ignorePrefix = this.ignoreConf.get("prefix");

				if (ignorePrefix != null) {
					if (ignorePrefix.equals("")) {
						error = "";
					} else {
						String replacedError = (error + "\n").replaceAll("(?i)^(" + ignorePrefix + "(.*\\r?\\n){" + this.ignoreConf.get("line") +"})*", "").trim();
						// If ErrorStream contains anything other than Warning, it displays all the contents before substitution.
						if (replacedError.equals(""))  error = "";
					}
				}
			}

			if (!error.equals(""))  throw new RuntimeException(error.replaceAll("\\s+$", ""));
		} finally {
			if (stdout != null)  stdout.close();
			if (stderr != null)  stderr.close();
		}

		return result.replaceAll("\\s+$", "");
	}

	/**
	 * This function ignores the contents started with warning.
	 * 
	 * It can not be caught because it finds and deletes only the lines starting waring from the ErrorStream.
	 * 
	 * @param line  The number of lines of warning messages to ignore.
	 * @since 1.2
	 */
	public void ignoreWarning(int line) {
		ignoreWarning(line, "warning");
	}

	/**
	 * This function ignores the contents started with warning.
	 * 
	 * It can not be caught because it finds and deletes only the lines starting waring prefix from the ErrorStream.
	 * 
	 * @param line    The number of lines of warning messages to ignore.
	 * @param prefix  Warning message prefix ignoring case.
	 * @since 1.2
	 */
	public void ignoreWarning(int line, String prefix) {
		if (line > 0) {
			String ignorePrefix = this.ignoreConf.get("prefix");
			if (ignorePrefix == null || !ignorePrefix.equals("")) {
				this.ignoreConf.put("prefix", prefix);
				this.ignoreConf.put("line", String.valueOf(line));
			}
		}
	}

	/**
	 * This function ignores the ErrorStream.
	 * 
	 * @param ignore  Whether to ignore the ErrorStream.
	 * @since 1.2
	 */
	public void ignoreStderr(boolean ignore) {
		if (ignore)  this.ignoreConf.put("prefix", "");
	}

	/**
	 * This method converts the {@link Map} object used in Java to a JSON notation string
	 * and then escapes the string so that it can be available as an argument to the Command-line Interface.
	 * 
	 * Java provides escape processing when executing commands with the Command-line Interface.
	 * So this method has been deprecated.
	 * 
	 * @param  dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	 * @deprecated As of version 1.2.
	 */
	public String toJsonArg(Map<String, ?> dataset) {
		if (dataset == null)  return null;

		return toJsonArg(toJson(dataset));
	}

	/**
	 * This method converts the {@link Collection} object used in Java to a JSON notation string
	 * and then escapes the string so that it can be available as an argument to the Command-line Interface.
	 * 
	 * Java provides escape processing when executing commands with the Command-line Interface.
	 * So this method has been deprecated.
	 * 
	 * @param  dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	 * @deprecated As of version 1.2.
	 */
	public String toJsonArg(Collection<?> dataset) {
		if (dataset == null)  return null;

		return toJsonArg(toJson(dataset));
	}

	/**
	 * This method escapes the JSON notation string so that it can be available as an argument to the Command-line Interface.
	 * 
	 * Java provides escape processing when executing commands with the Command-line Interface.
	 * So this method has been deprecated.
	 * 
	 * This function escapes with a code notation of the unicode that is only available in the JSON notation string.
	 * So, you can only escape JSON notation strings.
	 * 
	 * @param  json  JSON notation string to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface.
	 * @deprecated As of version 1.2.
	 */
	public String toJsonArg(String json) {
		if (json == null)  return null;

		json = json.replaceAll("\\\\\\\\([^n|r|t|'|\"|\\\\])?", "\\\\u005c$1");  // replace \\ [w/o escape prefix] ==> \u005c
		json = json.replaceAll("\\\\\\\"", "\\\\\\\\\"");  // replace \" ==> \\"
		json = json.replaceAll("\\\"", "\\\\\"");          // replace " ==> \"
		json = json.replaceAll("&", "\\\\u0026");    // for unix shell & dos command
		json = json.replaceAll("!", "\\\\u0021");    // for unix shell
		json = json.replaceAll("`", "\\\\u0060");    // for unix shell
		json = json.replaceAll("[$]", "\\\\u0024");  // for unix shell
		json = json.replaceAll("<", "\\\\u003c");    // for dos command
		json = json.replaceAll(">", "\\\\u003e");    // for dos command
		json = json.replaceAll("[|]", "\\\\u007c");  // for dos command

		return "\"" + json + "\"";
	}

	/**
	 * This method converts {@link Map} object to A JSON notation string.
	 * 
	 * @param   dataset  {@link Map} object to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(Map<String, ?> dataset) {
		if (dataset == null)  return "null";

		// JsonObject object = Json.createObjectBuilder(dataset).build();
		// return object.toString();

		return getJsonObject(dataset).toString();
	}

	/**
	 * This method converts {@link Collection} object to A JSON notation string.
	 * 
	 * @param   dataset  {@link Collection} object to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(Collection<?> dataset) {
		if (dataset == null)  return "null";

		// JsonArray array = Json.createArrayBuilder(dataset).build();
		// return array.toString();

		return getJsonArray(dataset).toString();
	}

	/**
	 * This method converts {@link String} value to A JSON notation string.
	 * 
	 * @param   value  {@link String} value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(String value) {
		if (value == null)  return "null";

		JsonString string = Json.createValue(value);
		return string.toString();
	}

	/**
	 * This method converts double value to A JSON notation string.
	 * 
	 * @param   value  double value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(double value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts long value to A JSON notation string.
	 * 
	 * @param   value  long value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(long value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts int value to A JSON notation string.
	 * 
	 * @param   value  int value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(int value) {
		JsonNumber number = Json.createValue(value);
		return number.toString();
	}

	/**
	 * This method converts boolean value to A JSON notation string.
	 * 
	 * @param   value  boolean value to be converted to a JSON notation string.
	 * @return  A JSON notation string.
	 */
	public String toJson(boolean value) {
		return String.valueOf(value);
	}

	private JsonObject getJsonObject(Map<String, ?> dataset) {
		JsonObjectBuilder builder = Json.createObjectBuilder();

		try {
			Set<String> keySet = dataset.keySet();
			for (String key : keySet) {
				builder.add(key, getJsonValue(dataset.get(key)));
			}
		} catch(ClassCastException e) {
			throw new IllegalArgumentException(String.format("The key of the map should be a String. (%s)", e.getMessage()));
		}

		return builder.build();
	}

	private JsonArray getJsonArray(Collection<?> dataset) {
		JsonArrayBuilder builder = Json.createArrayBuilder();

		for (Object data : dataset) {
			builder.add(getJsonValue(data));
		}

		return builder.build();
	}

	private JsonValue getJsonValue(Object object) {
		if (object == null)  return JsonValue.NULL;


		if (object instanceof Map) {
			@SuppressWarnings("unchecked")
			Map<String, Object> mapValue = (Map<String, Object>)object;
			return getJsonObject(mapValue);
		} else if (object instanceof Map[]) {
			@SuppressWarnings("unchecked")
			Map<String, Object>[] values = (Map<String, Object>[])object;
			return getJsonArray(Arrays.asList(values));
		}
		else if (object instanceof Collection  )   return getJsonArray((Collection<?>)object);
		else if (object instanceof String      )   return Json.createValue((String)object);
		else if (object instanceof Boolean     )   return ((Boolean)object ? JsonValue.TRUE : JsonValue.FALSE);
		else if (object instanceof BigDecimal  )   return Json.createValue((BigDecimal)object);
		else if (object instanceof BigInteger  )   return Json.createValue((BigInteger)object);
		else if (object instanceof Double      )   return Json.createValue((double)object);
		else if (object instanceof Integer     )   return Json.createValue((int)object);
		else if (object instanceof Long        )   return Json.createValue((long)object);
		else if (object instanceof Byte        )   return Json.createValue((int)(byte)object);
		else if (object instanceof Short       )   return Json.createValue((int)(short)object);
		else if (object instanceof Character   )   return Json.createValue(String.valueOf((char)object));
		else if (object instanceof Date        )   return Json.createValue(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format((Date)object));
		else if (object instanceof Float       )   return Json.createValue(Double.valueOf(String.valueOf((float)object)));
		else if (object instanceof String[]    ) { String[]     values = (String[])object;      return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Boolean[]   ) { Boolean[]    values = (Boolean[])object;     return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof BigDecimal[]) { BigDecimal[] values = (BigDecimal[])object;  return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof BigInteger[]) { BigInteger[] values = (BigInteger[])object;  return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Double[]    ) { Double[]     values = (Double[])object;      return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Integer[]   ) { Integer[]    values = (Integer[])object;     return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Long[]      ) { Long[]       values = (Long[])object;        return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Byte[]      ) { Byte[]       values = (Byte[])object;        return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Short[]     ) { Short[]      values = (Short[])object;       return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Character[] ) { Character[]  values = (Character[])object;   return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Date[]      ) { Date[]       values = (Date[])object;        return getJsonArray(Arrays.asList(values)); }
		else if (object instanceof Float[]) {
			Float[] values = (Float[])object;
			List<Double> valueList = new ArrayList<>();

			for (float value : values) {
				valueList.add(Double.valueOf(String.valueOf(value)));
			}

			return getJsonArray(valueList);
		} else if (object instanceof double[]) {
			Double[] values = Arrays.stream((double[])object).boxed().toArray(Double[]::new);
			return getJsonArray(Arrays.asList(values));
		} else if (object instanceof int[]) {
			Integer[] values = Arrays.stream((int[])object).boxed().toArray(Integer[]::new);
			return getJsonArray(Arrays.asList(values));
		} else if (object instanceof long[]) {
			Long[] values = Arrays.stream((long[])object).boxed().toArray(Long[]::new);
			return getJsonArray(Arrays.asList(values));
		} else if (object instanceof float[]) {
			float[] values = (float[])object;
			List<Double> valueList = new ArrayList<>();

			for (float value : values) {
				valueList.add(Double.valueOf(String.valueOf(value)));
			}

			return getJsonArray(valueList);
		} else if (object instanceof boolean[]) {
			boolean[] values = (boolean[])object;
			List<Boolean> valueList = new ArrayList<>();

			for (boolean value : values) {
				valueList.add(Boolean.valueOf(value));
			}

			return getJsonArray(valueList);
		} else if (object instanceof byte[]) {
			byte[] values = (byte[])object;
			List<Byte> valueList = new ArrayList<>();

			for (byte value : values) {
				valueList.add(Byte.valueOf(value));
			}

			return getJsonArray(valueList);
		} else if (object instanceof short[]) {
			short[] values = (short[])object;
			List<Short> valueList = new ArrayList<>();

			for (short value : values) {
				valueList.add(Short.valueOf(value));
			}

			return getJsonArray(valueList);
		} else if (object instanceof char[]) {
			char[] values = (char[])object;
			List<Character> valueList = new ArrayList<>();

			for (char value : values) {
				valueList.add(Character.valueOf(value));
			}

			return getJsonArray(valueList);
		}

		throw new IllegalArgumentException(String.format("Type %s is not supported.", object.getClass()));
	}

	/**
	 * The JSON notation string is converted to {@link Map}, {@link List}, {@link String}, {@link Boolean}, {@link Integer}, {@link Long}, or {@link Double} used in Java.
	 * 
	 * @param   json  JSON notation string to be converted to a object used in Java.
	 * @return  A object used in Java.
	 */
	public <T> T fromJson(String json) {
		return fromJson(json, false);
	}


	/**
	 * The JSON notation string is converted to {@link Map}, {@link List}, {@link String}, {@link Boolean}, {@link Integer}, {@link Long}, or {@link Double} used in Java.
	 * 
	 * <P>
	 * If stringValueOnly is true, the values of the JSON is converted to a string value only.
	 * 
	 * @param   stringValueOnly  Whether to convert values to strings only.
	 * @param   json  JSON notation string to be converted to a object used in Java.
	 * @return  A object used in Java.
	 * @since   1.1
	 */
	@SuppressWarnings("unchecked")
	public <T> T fromJson(String json, boolean stringValueOnly) {
		JsonReader reader = Json.createReader(new StringReader(json));
		return (T)parseJsonValue(reader.readValue(), stringValueOnly);
	}

	private Map<String, Object> parseJsonObject(JsonObject object, boolean stringValueOnly) {
		Map<String, Object> map = new HashMap<>();

		Set<String> keySet = object.keySet();
		for (String key : keySet) {
			map.put(key, parseJsonValue(object.get(key), stringValueOnly));
		}

		return map;
	}

	private List<?> parseJsonArray(JsonArray array, boolean stringValueOnly) {
		List<Object> list = new ArrayList<>();

		for (JsonValue value : array) {
			list.add(parseJsonValue(value, stringValueOnly));
		}

		return list;
	}

	private Object parseJsonValue(JsonValue value, boolean stringValueOnly) {
		switch (value.getValueType()) {
			case NULL:
				return null;
			case TRUE:
				return stringValueOnly ? "true" : true;
			case FALSE:
				return stringValueOnly ? "false" : false;
			case STRING:
				return ((JsonString)value).getString();
			case NUMBER:
				JsonNumber number = (JsonNumber)value;

				if (stringValueOnly) {
					return number.toString();
				} else {
					long   longValue   = number.longValue();
					double doubleValue = number.doubleValue();
	
					if (Math.ceil(Math.abs(doubleValue)) == Math.abs(longValue)) {
						if (longValue >= -2147483648 && longValue <= 2147483647) {
							return number.intValue();
						} else  {
							return longValue;
						}
					} else {
						return doubleValue;
					}
				}
			case ARRAY:
				return parseJsonArray((JsonArray)value, stringValueOnly);
			case OBJECT:
				return parseJsonObject((JsonObject)value, stringValueOnly);
			default:
				return null;
		}
	}
}