# Bridge/Ruby | http://commandbridge.org
require "json"

module Gurumdari
	# Bridge/Ruby enables you to get results from other languages through the Command-line Interface.
	# 
	# == Author:
	# Jeasu Kim
	class CommandBridge

		# Bridge/Ruby enables you to get results from other languages through the Command-line Interface.
		#
		# Since the execution result is a character string, it can be solved by parsing from JSON notation string result as Value Object.
		#
		# Although the dataset is a value object used in Ruby, it is automatically converted into a JSON notation string
		# and converted into a string that can be used in the Command-line Interface.
		# Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
		#
		# == Parameters:
		# commands:: Command list.
		# dataset::  Data set to be converted to argument.
		# arg_sep::  A delimiter that separates Command and Argument.
		#
		# == Returns:
		# String result executed through Command-line Interface.
		def call(commands, dataset = nil, arg_sep = nil)
			json_arg = toJsonArg(dataset)

			if json_arg == "\"\""
				json_arg = nil
			end

			commands.each_with_index do |command, index|
				if command.scan(/\s/).count > 0 || command.scan(/\"/).count > 0 || command.scan(/\'/).count > 0
					commands[index] = "\"" + command.gsub(/\"/, "\\\"") + "\""
				end
			end

			unless json_arg.nil?
				unless arg_sep.nil?
					commands.push(arg_sep)
				end

				commands.push(json_arg)
			end

			commands.push("2>&1")
			command = commands. * " "
			result = ""

			IO.popen(command, "r+") do |pipe|
				result = pipe.read
			end

			result = result.gsub(/\s+$/, '')

			unless $?.success?
				raise result
			end

			result
		end

		# The dataset is a value object used in Ruby, but it is automatically converted to a JSON notation string and returns a string that can be used in Command-line Interface.
		#
		# == Parameters:
		# dataset::  Data set to be converted to argument.
		#
		# == Returns:
		# A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
		def toJsonArg(dataset)
			if dataset.nil?
				return nil
			end

			json_arg = ""

			if (dataset.instance_of? String)
				json_arg = dataset
			else
				json_arg = JSON.generate(dataset)
			end

			json_arg = json_arg.gsub(/\\\\([^n|r|t|'|\"|\\])?/, "\\u005c\\1")  # replace \\ [w/o escape prefix] ==> \u005c
			json_arg = json_arg.gsub(/\\\"/, "\\\\\\\\\"")  # replace \" ==> \\"
			json_arg = json_arg.gsub(/\"/, "\\\"")      # replace " ==> \"
			json_arg = json_arg.gsub(/&/, "\\u0026")    # for unix shell & dos command
			json_arg = json_arg.gsub(/!/, "\\u0021")    # for unix shell
			json_arg = json_arg.gsub(/`/, "\\u0060")    # for unix shell
			json_arg = json_arg.gsub(/[$]/, "\\u0024")  # for unix shell
			json_arg = json_arg.gsub(/</, "\\u003c")    # for dos command
			json_arg = json_arg.gsub(/>/, "\\u003e")    # for dos command
			json_arg = json_arg.gsub(/[|]/, "\\u007c")  # for dos command
			"\"" + json_arg + "\""
		end
	end
end