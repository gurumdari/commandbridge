<?php
########################################
# RemoteBridge/PHP Configuration       #
########################################
$remotebridge_conf = [
	'system' => [
		'commandbridge_path' => "{$_SERVER['DOCUMENT_ROOT']}/path/to/path/CommandBridge.php",
		'direct_access' => true,
		'workspace_root' => '/your/path/to/path'
	],
	'security' => [
		'username' => 'remotebridge',
		'password' => 'remotebridge',
		'response_delay' => 0
	]
];

putenv('LANG=en_GB.UTF-8');
########################################

$request_uri_only = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (!$remotebridge_conf['system']['direct_access'] && __FILE__ == $_SERVER['DOCUMENT_ROOT'].$request_uri_only) {
	http_response_code(404);
} else {
	function getErrorMessage($message, $code) {
		error_log($message);

		$error = [
			'error-code'    => $code,
			'error-message' => $message
		];

		echo json_encode($error);
	}

	if (isset($_POST['username']) && isset($_POST['password']) && $_POST['username'] === $remotebridge_conf['security']['username'] && $_POST['password'] === $remotebridge_conf['security']['password']) {
		if (isset($_POST['commands'])) {
			try {
				$commands = $_POST['commands'];

				if (isset($remotebridge_conf['system']['workspace_root'])) {
					for ($i = 0; $i < count($commands); $i++) {
						$commands[$i] = str_replace('${workspace_root}', $remotebridge_conf['system']['workspace_root'], $commands[$i]);
					}
				}

				$dataset = null;
				$arg_sep = null;

				if (isset($_POST['dataset'])) {
					$dataset = $_POST['dataset'];

					// Since PHP encodes in UTF-8 rather than Unicode (UTF-16), characters over 2 bytes can be missed.
					$decoded = json_decode($dataset);

					if (!(gettype($decoded) == "string" && strlen($decoded) == 0)) {
						$dataset = json_encode($decoded);
					}
				}

				if (isset($_POST['arg_sep'])) {
					$arg_sep = $_POST['arg_sep'];
				}

				require_once $remotebridge_conf['system']['commandbridge_path'];
				$bridge = new \Gurumdari\CommandBridge();
	
				$bridge->setConfig($_POST['options']);
				$result = $bridge->call($commands, $dataset, $arg_sep);

				echo $result;
			} catch (\Error $e) {
				getErrorMessage($e->getMessage(), 500);
			} catch (\Exception $e) {
				getErrorMessage($e->getMessage(), 500);
			}
		} else {
			getErrorMessage('commands is undefined', 500);
		}
	} else {
		$delay_seconds = 0;
		if (isset($remotebridge_conf['security']['response_delay'])) {
			$delay_seconds = (int)$remotebridge_conf['security']['response_delay'];
		}

		if ($delay_seconds > 0) {
			sleep($delay_seconds);
		}

		getErrorMessage('Access denied. (username or password is wrong)', 500);
	}
}