/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * https://commandbridge.org
 */
package com.gurumdari;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Remote Server에서 CommandBridge로 실행한 결과를 REST API로 통신으로 처리해주는 Servlet.
 * 
 * @version 1.3, 2019-03-13
 * @author  Jeasu Kim
 */
public class RemoteBridge extends HttpServlet {
	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	private Logger logger = LogManager.getLogger(getClass());

	/**
	 * Remote Server에서 CommandBridge로 실행한 결과를 REST API로 통신으로 처리한다.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String workspaceRoot = getServletConfig().getInitParameter("workspace_root");
		String username      = getServletConfig().getInitParameter("username");
		String password      = getServletConfig().getInitParameter("password");

		response.setContentType("plain/text; charset=UTF-8");
		PrintWriter out = response.getWriter();

		if (username.equals(request.getParameter("username")) && password.equals(request.getParameter("password"))) {
			String[] commands = request.getParameterValues("commands[]");

			if (commands == null || commands.length == 0) {
				out.print(getErrorMessage("commands is undefined", 500));
			} else {
				if (workspaceRoot != null) {
					for (int i = 0; i < commands.length; i++) {
						commands[i] = commands[i].replaceAll("\\$\\{workspace_root\\}", workspaceRoot);
					}
				}

				try {
					CommandBridge bridge = new CommandBridge();
	
					bridge.setConfig(request.getParameter("options"));
					String result = bridge.call(commands, request.getParameter("dataset"), request.getParameter("arg_sep"));
	
					out.print(result);
				} catch(Exception e) {
					out.print(getErrorMessage(e.getMessage(), 500));
				}
			}
		} else {
			out.print(getErrorMessage("Access denied. (username or password is wrong)", 500));
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.sendError(404, "File Not Found");
	}

	private String getErrorMessage(String message, int code) {
		return getErrorMessage(message, code, null);
	}

	private String getErrorMessage(String message, int code, Throwable throwable) {
		logger.error(message, throwable);

		Map<String, Object> errorData = new HashMap<>();
		errorData.put("error-code"   , code);
		errorData.put("error-message", message);

		return new CommandBridge().toJson(errorData);
	}
}