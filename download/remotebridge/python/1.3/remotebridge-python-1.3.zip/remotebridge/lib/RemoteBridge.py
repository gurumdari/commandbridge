""" RemoteBridge/Python | https://commandbridge.org """
import logging
import json
import re
import configparser
import CommandBridge as bridge
from flask import Flask, request, Response
from logging.handlers import RotatingFileHandler
from string import Template

""" RemoteBridge enables you to receive the result of calling remote server's command with CommandBridge via REST API.

Versions:
	1.0 (2019-03-13): first release for RemoteBridge with Python.
Author:
	Jeasu Kim
"""

config = configparser.ConfigParser()
config.read('../conf/remotebridge.ini')

logging_level = {
	'CRITICAL': logging.CRITICAL,
	'ERROR':    logging.ERROR,
	'WARNING':  logging.WARNING,
	'INFO':     logging.INFO,
	'DEBUG':    logging.DEBUG,
	'NOTSET':   logging.NOTSET
}

app = Flask(__name__)

def getErrorMessage(message, code):
	app.logger.error(message)

	error = {
		'error-code':    code,
		'error-message': message
	}

	return json.dumps(error)

def runCommandBridge():
	try:
		if (request.form.get('username') == config['security']['username'] and request.form.get('password') == config['security']['password']):
			commands = request.form.getlist('commands[]')

			if commands is None or len(commands) == 0:
				return getErrorMessage('commands is undefined', 500)
			else:
				for index, command in enumerate(commands):
					commands[index] = Template(command).substitute(workspace_root=config['system']['workspace_root'])

				bridge.setConfig(request.form.get('options'))

				return bridge.call(commands, request.form.get('dataset'), request.form.get('arg_sep'))
		else:
			return getErrorMessage('Access denied. (username or password is wrong)', 500)
	except (Exception, RuntimeError) as e:
		return getErrorMessage(str(e), 500)

@app.route(config['system']['route_uri'], methods=['POST'])
def serve():
	return runCommandBridge()

@app.errorhandler(403)
def forbidden(e):
	return getErrorMessage(str(e), 403)

@app.errorhandler(404)
def page_not_found(e):
	return getErrorMessage(str(e), 404)

handler = RotatingFileHandler('../logs/remotebridge.log', maxBytes=10000, backupCount=10)
handler.setLevel(logging_level[config['system']['logging_level']])
handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s - %(message)s in %(pathname)s:%(lineno)d"))
app.logger.addHandler(handler)