""" Bridge/Python | http://commandbridge.org """
import json
import re
import subprocess

""" Bridge/Python enables you to get results from other languages through the Command-line Interface.

Bridge/Python is supported since Python 2.6. Bridge/Python is implemented not only in Python 2.x, but also in Python 3.x.
"""

def call(commands, dataset = None, arg_sep = None):
	""" Bridge/Python enables you to get results from other languages through the Command-line Interface.

	Since the execution result is a character string, it can be solved by parsing from JSON notation string result as Value Object.

	Although the dataset is a value object used in Python, it is automatically converted into a JSON notation string
	and converted into a string that can be used in the Command-line Interface.
	Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.

	Args:
		commands (list):                 Command list.
		dataset (dict or str, optional): Data set to be converted to argument.
		arg_sep (str, optional):         A delimiter that separates Command and Argument.

	Returns:
		str: String result executed through Command-line Interface.
	"""

	json_arg = toJsonArg(dataset)

	if json_arg == "\"\"": json_arg = None

	for index, command in enumerate(commands):
		if (re.search("\s", command) is not None or re.search("\"", command) is not None or re.search("\'", command) is not None):
			commands[index] = "\"" + re.sub("\\\"", "\\\"", command) + "\""

	if json_arg is not None:
		if arg_sep is not None: commands.append(arg_sep)

		commands.append(json_arg)

	command = " ".join(commands)

	pipe = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
	(stdout, stderr) = pipe.communicate()

	if stderr is not None:
		try:
			stderr = stderr.decode("ascii")
		except UnicodeDecodeError:
			stderr = stderr.decode('utf-8')

		if (stderr != ""):
			raise RuntimeError(stderr.rstrip())

		try:
			return stdout.decode("ascii").rstrip()
		except UnicodeDecodeError:
			return stdout.decode('utf-8').rstrip()

def toJsonArg(dataset):
	""" The dataset is a value object used in Python, but it is automatically converted to a JSON notation string and returns a string that can be used in Command-line Interface.

	Args:
		dataset (dict or str): Data set to be converted to argument.

	Returns:
		str: A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	"""

	if dataset is None: return None

	json_arg = ""

	if (type(dataset) is str):
		json_arg = dataset
	else:
		json_arg = json.dumps(dataset)

	json_arg = re.sub(r"\\\\([^n|r|t|'|\"|[\]])?", r"\u005c\1", json_arg)        # replace \ [w/o escape prefix] ==> \u005c ((NOTE: Why is backslash ignored!!))
	json_arg = re.sub("\\\\u005c\\\\\\\\u005c", "\\u005c\\u005c\\\\", json_arg)  # replace \u005c\\u005c [w/o escape prefix] ==> \u005c\u005c\
	json_arg = re.sub(r"\\\\([^n|r|t|'|\"|[\]])?", r"\u005c\1", json_arg)        # replace \ [w/o escape prefix] ==> \u005c
	json_arg = re.sub("\\\\\\\"", "\\\\\\\"", json_arg)  # replace \" ==> \\"
	json_arg = re.sub("\\\"", "\\\"", json_arg)          # replace " ==> \"
	json_arg = re.sub("&", "\u0026", json_arg)    # for unix shell & dos command
	json_arg = re.sub("!", "\u0021", json_arg)    # for unix shell
	json_arg = re.sub("`", "\u0060", json_arg)    # for unix shell
	json_arg = re.sub("[$]", "\u0024", json_arg)  # for unix shell
	json_arg = re.sub("<", "\u003c", json_arg)    # for dos command
	json_arg = re.sub(">", "\u003e", json_arg)    # for dos command
	json_arg = re.sub("[|]", "\u007c", json_arg)  # for dos command

	return "\"" + json_arg + "\""